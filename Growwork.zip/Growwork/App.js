/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  StatusBar,
  View,
} from 'react-native';
import Language from './App/UI/Components/Language';
import TermsPopUp from './App/UI/Sections/General/Screens/Terms';
import CommonDataManager from './App/UI/Utils/CommonManager';
import RNExitApp from 'react-native-exit-app';
import { AppColors, ScreenNames } from './App/UI/Utils/AppConstants';
import { NavigationContainer } from '@react-navigation/native';
import AppStack from './App/Navigation/MainNavigation';
import { useDispatch, useSelector } from 'react-redux';
import { setBottomSpace, setCurrentFont, setLang, setTheme } from './App/Redux/actions/AppLogics';
import { AppRootStore } from './App/Redux/store/AppStore';
import { AppStyles } from './App/UI/Utils/AppStyles';
import Geocoder from 'react-native-geocoding';
import SplashScreen from 'react-native-splash-screen';
import SafeArea from 'react-native-safe-area';
import AppLoader from './App/UI/Components/AppLoader';
const App = () => {
  const [popUp, setShowPopUp] = useState(false)
  const [termspopUp, setTermsShowPopUp] = useState(false)
  const dispatch = useDispatch()
  const selector = useSelector((AppState: AppRootStore) => AppState);
  var [screenName, setScreenName] = useState('');
  const setAppScreen = async () => {
    let term = await CommonDataManager.getSharedInstance().loadTerms()
    if (term) {
      let lang = await CommonDataManager.getSharedInstance().loadLang()
      if (lang) {
        dispatch(setLang(lang == "0" ? "english" : "hindi"))
        setScreenName(ScreenNames.Container)
        setShowPopUp(false)
        let theme = await CommonDataManager.getSharedInstance().getTheme()
        if (theme) {
          console.log("current theme" + theme)
          dispatch(setTheme(JSON.parse(theme)))
        }
        let font = await CommonDataManager.getSharedInstance().getFont()
        if (font) {
          dispatch(setCurrentFont(font))
        }
        else {
          dispatch(setCurrentFont(1))
        }
      }
      else {
        setShowPopUp(true)
      }
      // const user = await CommonDataManager.getSharedInstance().loadLoginUser()
      // if (user) {
      //   dispatch(setCurrentUser(user))
      // }
      // else {
      //   setShowPopUp(true)
      // }
    }
    else {
      setTermsShowPopUp(true)
    }
    SplashScreen.hide()
  }
  useEffect(() => {
    SafeArea.getSafeAreaInsetsForRootView().then(result => {
      if (selector.AppReducer.bottomSpace != result.safeAreaInsets.bottom) {
        if (result.safeAreaInsets.bottom != 0) {
          dispatch(setBottomSpace(result.safeAreaInsets));

          console.log(
            'bottom == > ' + JSON.stringify(selector.AppReducer.bottomSpace),
          );
        }
      }
    });
    Geocoder.init('AIzaSyBQyEE67gM0AvoJAzwp7fSdDlPqKwqKTxU', {
      language: 'en',
    });
    CommonDataManager.getSharedInstance().setReduxReducer(selector, dispatch)
    setAppScreen()
  }, [])
  return (
    <View
      style={{
        flex: 1,
      }}
    >
      <StatusBar
      backgroundColor = {selector.AppReducer.currentTheme == 0 ? AppColors.blue.lightDarkBlue : AppColors.black.black}
        barStyle= {selector.AppReducer.currentTheme == 0 ? "dark-content" : "light-content"}
      />
      {
        termspopUp == true ?
          <TermsPopUp
            onSelect={async (type) => {
              if (type == 0) {
                RNExitApp.exitApp();
              }
              else {
                let save = await CommonDataManager.getSharedInstance().saveTerms(1)
                setAppScreen()
                setTermsShowPopUp(false)
              }
            }}
          />
          : null
      }
      {
        popUp == true ?
          <Language
            onContinue={() => {
              setAppScreen()
            }}
          />
          : null
      }
      {
        selector.AppReducer.isLoaderStart ?
        <AppLoader/>
        : null
      }
      {
        screenName != "" ?
          <NavigationContainer>
            <AppStack />
          </NavigationContainer> :
          null
      }
    </View>
  );
};
export default App;
