
module.exports = {
    assets : ["./App/UI/assets/fonts"]
}