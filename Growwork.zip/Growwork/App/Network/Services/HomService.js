import axios from "axios"
import { ApiResponseHandler } from "../ApiResponseHandler"
import { SERVICE_LIST_URL } from "../Urls"
export const servicesRequest = async(params)=> {
    console.log(params)
    let response = {}
    let url = SERVICE_LIST_URL
    let apiRequest = await axios.post(url,params).catch((error)=>{
        return response = {
            data : [],
            code : 422
        }
    })
    response = apiRequest.data
    return response
}
