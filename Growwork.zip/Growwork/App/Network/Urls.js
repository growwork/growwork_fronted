export const BASE_URL = "https://growwork.herokuapp.com/api/"
export const IMAGE_BASE_URL = "https://growwork.herokuapp.com"
export const SERVICE_LIST_URL = BASE_URL + "dashboard"
