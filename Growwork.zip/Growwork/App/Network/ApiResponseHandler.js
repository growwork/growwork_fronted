export interface ApiResponseHandler<T> {
    data: T,
    code : number
}