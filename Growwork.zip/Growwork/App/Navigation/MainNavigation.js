import React, { useEffect } from 'react';

import {
    createStackNavigator,
    CardStyleInterpolators,
} from '@react-navigation/stack';
import { createDrawerNavigator, DrawerContent } from '@react-navigation/drawer';
import Home from '../UI/Sections/Home/Screens/Home';
import { ScreenNames } from '../UI/Utils/AppConstants';
import DrawerContents from './Components/DrawerContents';
import { Settings } from 'react-native';
import Setting from '../UI/Sections/Settings/Screens/Settings';
import Login from '../UI/Sections/Authentication/Screens/Login';
import Signup from '../UI/Sections/Authentication/Screens/Signup';
import ItemProfile from '../UI/Sections/Home/Screens/ItemProfile';
import CitiesList from '../UI/Sections/Home/Screens/CityList';
import Career from '../UI/Sections/Career/Screens/Career';
import AdForm from '../UI/Sections/Ad/Screens/AdForm';
import Offers from '../UI/Sections/Offer/Screens/Offers';
const DrawerStack = createDrawerNavigator();
const MainStack = createStackNavigator();
const AppStack = () => {
    return (
        <MainStack.Navigator
            initialRouteName={ScreenNames.Container}
            screenOptions={{
                headerShown: false,
                cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                gestureEnabled: true,
            }}>
            <MainStack.Screen
                component={Drawer}
                name={ScreenNames.Container}
            />
            <MainStack.Screen
                component={Setting}
                name={ScreenNames.Settings.Settings}
            />
            <MainStack.Screen
                component={Login}
                name={ScreenNames.Authentication.Login}
            />
            <MainStack.Screen
                component={Signup}
                name={ScreenNames.Authentication.Signup}
            />
            <MainStack.Screen
                component={Career}
                name={ScreenNames.Career.career}
            />
            <MainStack.Screen
                component={AdForm}
                name={ScreenNames.Ad.ad}
            />
            <MainStack.Screen
                component={Offers}
                name={ScreenNames.Offer.offers}
            />
            <MainStack.Screen
                component={ItemProfile}
                name={ScreenNames.Home.ItemProfile}
            />
            <MainStack.Screen
                component={CitiesList}
                name={ScreenNames.Home.City}
            />
        </MainStack.Navigator>
    )
}
const Drawer = () => {
    return (
        <DrawerStack.Navigator
            drawerContent={(props) => <DrawerContents {...props} />}
        >
            <DrawerStack.Screen
                component={Home}
                name={ScreenNames.Home.Home}
            />
        </DrawerStack.Navigator>
    )
}
export default AppStack