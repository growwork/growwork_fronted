import React from 'react';
import { View, Text, SafeAreaView, SectionList, Image, ScrollView } from 'react-native';
import {
    DrawerContentScrollView,
    DrawerItem,
    DrawerNavigationProp,
    DrawerContentComponentProps,
} from '@react-navigation/drawer';
import { useDispatch, useSelector } from 'react-redux';
import { AppStyles, AppStyleWithProps } from '../../UI/Utils/AppStyles';
import { AppRootStore } from '../../Redux/store/AppStore';
import { AppColors, AppImages, ContainerGuestList, hv, ScreenNames } from '../../UI/Utils/AppConstants';
import { DrawerStyles, DrawerStylesWithProps } from '../Styles/DrawerStyles';
import CommonDataManager from '../../UI/Utils/CommonManager';
import DrawerSingleItems from './DrawerSingleItem';
const DrawerContents = (props: DrawerContentComponentProps) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const dispath = useDispatch();
    return (
        <View style={{
            ...AppStyles.MainStyle,
            ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor
        }}>
            <ScrollView>
                <View
                    style={DrawerStylesWithProps(selector.AppReducer.currentTheme).drawerTopViewStyle}>
                    <Image
                        source={AppImages.Drawer.userDummy}
                        style={{
                            height: hv(80),
                            width: hv(80)
                        }}
                    />
                    <Text
                        style={DrawerStyles.topTitleStyle}
                    >
                        {
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Container", "guest")
                        }
                    </Text>
                </View>
                <View
                style = {{
                    marginTop : hv(30)
                }}
                >

                    {
                        ContainerGuestList.map((item, index) => {
                            return (
                                <View
                                    key={`${index}`}
                                >
                                    <DrawerSingleItems
                                        title={
                                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Container", item)
                                        }
                                        onClick={() => {
                                            props.navigation.toggleDrawer()
                                            if (index == 0) {
                                                props.navigation.push(ScreenNames.Authentication.Login)
                                            }
                                            if (index == 2) {
                                                props.navigation.push(ScreenNames.Settings.Settings)
                                            }
                                            if (index == 3) {
                                                props.navigation.push(ScreenNames.Career.career)
                                            }
                                            if (index == 4) {
                                                props.navigation.push(ScreenNames.Ad.ad)
                                            } 
                                            if (index == 5) {
                                                props.navigation.push(ScreenNames.Offer.offers)
                                            }
                                        }}
                                    />
                                </View>
                            )
                        })
                    }
                </View>
            </ScrollView>
            <SafeAreaView/>
        </View>
    )
}
export default DrawerContents