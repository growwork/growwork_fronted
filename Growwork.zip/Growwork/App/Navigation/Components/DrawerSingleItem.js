import React from 'react';
import { View, Text, SafeAreaView, SectionList, Image, ScrollView, TouchableWithoutFeedback } from 'react-native';
import { useSelector } from 'react-redux';
import CommonDataManager from '../../UI/Utils/CommonManager';
import { DrawerStyles, DrawerStylesWithProps } from '../Styles/DrawerStyles';
import { AppRootStore } from '../../Redux/store/AppStore';
const DrawerSingleItems = ({ title, onClick }) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <TouchableWithoutFeedback
        onPress = {()=>onClick()}
        >
            <View
                style={{
                    ...DrawerStyles.singleItemStyle,
                    justifyContent : "center"
                }}
            >
                <Text
                    style={{
                        ...DrawerStylesWithProps(selector.AppReducer.currentTheme).textStyle
                    }}
                >
                    {
                        title
                    }
                </Text>
                <View
                style = {DrawerStylesWithProps(selector.AppReducer.currentTheme).seperatorStyle}
                />
            </View>
        </TouchableWithoutFeedback>
    )
}
export default DrawerSingleItems