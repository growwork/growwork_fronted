import { Platform, StyleSheet } from 'react-native';
import { AppColors, hv, normalized } from '../../UI/Utils/AppConstants';
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from '../../UI/Utils/AppStyles';
import CommonDataManager from '../../UI/Utils/CommonManager';
export const DrawerStyles = StyleSheet.create({
    topTitleStyle : {
        color : AppColors.white.white,
        ...AppStyles.TextMediumStyle,
        fontSize : normalized(16),
        marginTop : hv(8)
    },
    singleItemStyle : {
       height : hv(45),
        marginHorizontal : AppHorizontalMargin,

    },
})
export const DrawerStylesWithProps = (props) => StyleSheet.create({
    drawerTopViewStyle : {
        height : hv(250),
        justifyContent : "center",
        alignItems : "center",
        backgroundColor : props == 0 ? AppColors.blue.lightDarkBlue : AppColors.white.lightishWhite
    },
    textStyle : {
        fontSize : normalized(18),
        ...AppStyles.TextCompactSemiboldStyle,
        ...AppStyleWithProps(props).textColor,
    },
    seperatorStyle : {
        ...AppStyleWithProps(props).seperatorsColor,
        height : hv(0.5),
        marginTop : hv(5)
    }
})
