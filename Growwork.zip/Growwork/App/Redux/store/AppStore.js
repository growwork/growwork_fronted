import {createStore,combineReducers} from "redux";
import AppReducer from "../reducers/AppReducer";
const rootReducer = combineReducers({
    AppReducer : AppReducer
});
const configureStore = () => createStore(
    rootReducer
);
export type AppRootStore = ReturnType<typeof rootReducer>

export default configureStore;