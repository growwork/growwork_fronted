import { SafeAreaInsets } from "react-native-safe-area"
import {SET_USER_REQUEST_LOCATION,START_LOADER, OPEN_MENU,SET_CURRENT_USER, SET_INITIAL_SCREEN, SET_INTERNET_STATE, SET_INTAKE_STATE,SET_LANG_STATE, SET_THEME_STATE, SET_BOTTOM_SPACE, SET_CART_VIEW, SET_CURRENT_FONT } from "./types"
export const startLoader = (isLoaderStart) => ({
    type: START_LOADER,
    data: isLoaderStart
})
export const toggleMenu = (menu) => ({
    type: OPEN_MENU,
    data: menu
})
export const toggleCart = (cart) => ({
    type: SET_CART_VIEW,
    data: cart
})
export const setCurrentUser = (user ) => ({
    type: SET_CURRENT_USER,
    data: user
})
export const setInitialScreen = (screen ) => ({
    type: SET_INITIAL_SCREEN,
    data: screen
})
export const setNetState = (connected ) => ({
    type: SET_INTERNET_STATE,
    data: connected
})
export const setIntake = (connected ) => ({
    type: SET_INTAKE_STATE,
    data: connected
})
export const setLang = (lang) => ({
    type: SET_LANG_STATE,
    data: lang
})
export const setTheme = (theme ) => ({
    type: SET_THEME_STATE,
    data: theme
})
export const setCurrentFont = (theme) => ({
    type: SET_CURRENT_FONT,
    data: theme
})
export const setBottomSpace = (space ) => ({
    type: SET_BOTTOM_SPACE,
    data: space
})
export const setUserRequestLoc = (obj) => ({
    type: SET_USER_REQUEST_LOCATION,
    data: obj
})
