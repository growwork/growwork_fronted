import SafeArea from "react-native-safe-area";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {SET_USER_REQUEST_LOCATION, START_LOADER, OPEN_MENU, SET_BOTTOM_SPACE, SET_CURRENT_USER, SET_INITIAL_SCREEN, SET_INTERNET_STATE, SET_INTAKE_STATE, SET_LANG_STATE, SET_THEME_STATE, SET_CURRENT_FONT } from "../actions/types"
const initialState = {
    isLoaderStart: false,
    openMenu: false,
    currentUser: null,
    screen: "",
    isNetConnected: false,
    isIntake: false,
    currentLanguage: "english",
    currentTheme: 0,
    bottomSpace: { bottom: 0, top: 0 },
    showCart: false,
    cartItems :[],
    currentFont : 1,
    isLocRequestCall: false

}
const AppReducer = (state = initialState, action) => {
    console.log(action.type)
    switch (action.type) {
        case START_LOADER:
            return {
                ...state,
                isLoaderStart: action.data
            };
        case OPEN_MENU:
            return {
                ...state,
                openMenu: action.data
            }
        case SET_CURRENT_USER:
            return {
                ...state,
                currentUser: action.data
            }
        case SET_INITIAL_SCREEN:
            return {
                ...state,
                screen: action.data
            }
        case SET_INTERNET_STATE:
            return {
                ...state,
                isNetConnected: action.data
            }
        case SET_LANG_STATE:
            return {
                ...state,
                currentLanguage: action.data
            }
        case SET_THEME_STATE:
            return {
                ...state,
                currentTheme: action.data
            }
        case SET_BOTTOM_SPACE:
            return {
                ...state,
                bottomSpace: action.data
            }
            case SET_CURRENT_FONT:
                return {
                    ...state,
                    currentFont: action.data
                }
                case SET_USER_REQUEST_LOCATION:
                    return {
                        ...state,
                        isLocRequestCall: action.data
                    }
        default:
            return state;
    }
}
export default AppReducer;