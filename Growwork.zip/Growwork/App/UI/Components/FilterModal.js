import React from "react"
import { useEffect } from "react"
import { useState } from "react"
import { View, TouchableWithoutFeedback,FlatList } from "react-native"
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from "react-native-reanimated"
import { AppColors, hv, ScreenSize } from "../Utils/AppConstants"
import { AppHorizontalMargin, AppStyles } from "../Utils/AppStyles"
import CheckBox from "./Checkbox"
import SimpleCheckBox from "./SimpleCheckBox"
interface FilterModalProps {
    data: [string],
    selectedIndex: number,
    onSelect: (index: number) => void,
    onClose: () => void
}
const FilterModal = (props :FilterModalProps ) => {
    const [selectedIndex,setSelectedIndex] = useState(props.selectedIndex)
    const setTranslateX = useSharedValue(-ScreenSize.width)
    const animatedStyle = useAnimatedStyle(()=>({
        transform : [
            {
                translateX : setTranslateX.value
            }
        ]
    }))
    useEffect(()=>{
        setTranslateX.value = withTiming(0 ,{
            duration : 250
        })
    },[])
    const setSelected = ()=> {
        setTranslateX.value = withTiming(ScreenSize.width ,{
            duration : 250
        })  
    }
    return (
        <TouchableWithoutFeedback
        onPress = {()=>props.onClose()}
        >
            <View
                style={{
                    height: "100%",
                    width: "100%",
                    zIndex: 4,
                    backgroundColor: AppColors.black.lightBlack,
                    justifyContent: "center",
                    position : "absolute"
                }}
            >
                <Animated.View
                    style={[{
                        marginHorizontal: 30,
                        backgroundColor: AppColors.white.white,
                        borderRadius : 10,
                        ...AppStyles.commonShadowStyle,
                    paddingHorizontal : AppHorizontalMargin,
                    height : props.data.length * hv(50),
                    },animatedStyle]}
                >
                    <FlatList
                    contentContainerStyle = {{flex : 1,justifyContent : "center"}}
                    data = {props.data}
                    keyExtractor = {(item,index)=>`${index}`}
                    renderItem = {({item,index})=>{
                        return(
                            <SimpleCheckBox
                            title = {item}
                            index = {index}
                            selected = {selectedIndex == index ? true : false}
                            setCheckBox = {()=> {
                                setSelected()
                                setTimeout(() => {
                                    setSelectedIndex(index)
                                    props.onSelect(index)
                                }, 260);
                            }}
                            />
                        )
                    }}
                    />
                </Animated.View>
            </View>
        </TouchableWithoutFeedback>
    )
}
export default FilterModal