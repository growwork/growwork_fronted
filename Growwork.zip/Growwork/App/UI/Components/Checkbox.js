import React from "react"
import { useEffect } from "react"
import { useState } from "react"
import {View,Text,Image,TouchableWithoutFeedback, Platform} from "react-native"
import { useDispatch, useSelector } from "react-redux"
import { AppColors,AppFonts, AppImages, normalized } from "../Utils/AppConstants"
import { AppStyles, AppStyleWithProps } from "../Utils/AppStyles"
import { AppRootStore } from "../../Redux/store/AppStore"
import CommonDataManager from "../Utils/CommonManager"
interface CheckBoxProps {
    selected : boolean,
    title : string,
    setCheckBox : (index : number)=>void,
    index : number
}
const CheckBox = (props : CheckBoxProps) => {
    const [selected,setSelected] = useState(props.selected)
    const dispatch = useDispatch();
    const selector = useSelector((AppState: AppRootStore) => AppState);
  
    useEffect(()=>{
        console.log(props.selected)
        if (selected != props.selected) {
            setSelected(props.selected)
        }
    })
    return(
        <TouchableWithoutFeedback
        onPress = {()=>props.setCheckBox(props.index)}
        >
        <View
        style = {{
            ...AppStyles.CheckBoxViewStyle
        }}
        >
            <Image
            source = {selected == true ? AppImages.Authentication.selectedBox : AppImages.Authentication.unselectedBox}
            />
            <Text
            style = {{
            marginLeft : 20,
            fontSize : Platform.OS == "android" ? normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)) : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,18)),
            fontFamily : AppFonts.PoppinMedium ,
            opacity : selected == true ? 1 : 0.7,
            ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor
            }}
            >
                {props.title}
            </Text>
        </View>
        </TouchableWithoutFeedback>
    )
}
export default CheckBox