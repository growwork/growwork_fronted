import React from "react"
import { TouchableWithoutFeedback,Image,View,Text } from "react-native"
import { useSelector } from "react-redux"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../Utils/AppStyles"
import CommonDataManager from "../Utils/CommonManager"
import { AppRootStore } from "../../Redux/store/AppStore"
import { AppImages, hv, normalized } from "../Utils/AppConstants"
import { HomeStyles } from "../Sections/Home/Styles/HomeStyles"
const RadioBtn = ({title,onPress,selected,white,viewStyle,textStyle}) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <TouchableWithoutFeedback
            onPress={() => onPress()}
        >
            <View
                style={{ ...AppStyles.HoriCommonStyle,justifyContent : "flex-start",marginVertical : 10,...viewStyle}}
            >
                <Image
                    source={ selected == true ? AppImages.Home.radioSelected : AppImages.Home.radioUnselected}
                    style = {{height : hv(25),width : hv(25),resizeMode : "contain"}}
                />
                <Text
                    style={{ ...HomeStyles.goStyle, marginLeft: normalized(5),...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)),
                        ...textStyle,
                    }}
                >
                    {
                        title
                    }
                </Text>
            </View>
        </TouchableWithoutFeedback>
    )
}
export default RadioBtn