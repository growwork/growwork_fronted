import React from "react"
import {TouchableWithoutFeedback, View,Image,Text} from "react-native"
import { useSelector } from "react-redux"
import { HomeStylesWithProps } from "../Sections/Home/Styles/HomeStyles";
import { AppStyles } from "../Utils/AppStyles";
import { AppRootStore } from "../../Redux/store/AppStore";
import { AppColors, AppImages, normalized } from "../Utils/AppConstants";
import CommonDataManager from "../Utils/CommonManager";
const AppTopBar = ({title,onBack}) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return(
        <View
        style = {{...HomeStylesWithProps(false).barStyle}}
        >
            <TouchableWithoutFeedback
            onPress = {()=>onBack()}
            >
                <Image
                source = {AppImages.Authentication.backBtn}
                style = {{
                    height : 28,
                    width : 28,
                    resizeMode : "contain"
                }}
                />
            </TouchableWithoutFeedback>
            <View>
            <Text
            style = {{
                ...AppStyles.TextCompactMediumStyle,
                fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,24)),
                color : AppColors.white.white,
                textAlign : "center",
            }}
            >
            {title}
            </Text>
            </View>
            <View>
                <TouchableWithoutFeedback>
                <Text
            style = {{
                ...AppStyles.TextCompactMediumStyle,
                fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)),
                color : AppColors.white.white,
                textAlign : "center",
                opacity : 0
            }}
            >
                city
            </Text>
                </TouchableWithoutFeedback>
            </View>
        </View>
    )
}
export default AppTopBar