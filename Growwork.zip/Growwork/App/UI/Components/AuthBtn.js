import React from "react"
import {View,Image,TextInput,TouchableWithoutFeedback, Text} from "react-native"
import { normalized } from "../Utils/AppConstants"
import { AppStyles } from "../Utils/AppStyles"
import CommonDataManager from "../Utils/CommonManager"
import { useSelector } from "react-redux"
import { AppRootStore } from "../../Redux/store/AppStore";
interface BtnProps {
    onClick : ()=>void,
    title : string,
    btnStyle : any | null
}
const AuthBtn = (props : BtnProps) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return(
        <TouchableWithoutFeedback
        onPress = {()=>props.onClick()}
        >
            <View
            style = {[AppStyles.AuthBtnStyle,props.btnStyle]}
            >
                <Text
                style = {{...AppStyles.AuthBtnTextStyle,
                    fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,24)),
                }}
                >
                    {props.title}
                </Text>
            </View>
        </TouchableWithoutFeedback>
    )
}
export default AuthBtn