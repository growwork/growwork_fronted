import { KeyboardType } from "@twotalltotems/react-native-otp-input"
import React, { useEffect, useState } from "react"
import { View, TextInput, Image, Text, StyleProp, ViewStyle, TextStyle,TouchableWithoutFeedback } from "react-native"
import { useSelector } from "react-redux"
import { AppRootStore } from "../../Redux/store/AppStore"
import { AppColors, AppFonts, AppImages, hv, normalized } from "../Utils/AppConstants"
import { AppHorizontalMargin, AppStyles } from "../Utils/AppStyles"
import CommonDataManager from "../Utils/CommonManager"
interface ProfileTextFieldProps {
    viewStyle?: StyleProp<ViewStyle>,
    textStyle?: StyleProp<TextStyle>,
    image?: any,
    type? : KeyboardType,
    inputStyle? : StyleProp<TextStyle>,
    placeHolder? : string,
    value? : string,
    title? : string,
    isSecure? : boolean,
    isDropDown : boolean,
    onDropDownSelect : ()=>void
}
const AppTextField = (props: ProfileTextFieldProps) => {
    const [iconColor, setIconColor] = useState(AppColors.green.appDarkGreen)
    const [value,setValue] = useState("")
    const [secure,setSecure] = useState(props.isSecure)
    const selector = useSelector((AppState) => AppState);

    useEffect(()=>{
        console.log("useEffect call")
        if (props.value) {
        setValue(props.value)
        }
    },[props.value])
    return (
        <TouchableWithoutFeedback
        disabled = {props.isDropDown ? false : true}
        onPress = {()=>props.onDropDownSelect()}
        >
        <View
            style={[
                props.viewStyle
            ]}
        >
            {
                props.title ? 
                <Text
                style={[{
                    marginTop: hv(20),
                    fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,12)),
                    color: AppColors.black.lightOP,
                    fontFamily: AppFonts.sfCompactDisplayRegular
                }, props.textStyle]}
            >
                {props.title}
            </Text> :
            null
            }

            <View
                style={{
                    ...AppStyles.TextFieldStyle,
                    shadowColor: AppColors.shadowColor.lightBlack,
                    shadowRadius: 2,
                    shadowOffset: { width: 0, height: 0 },
                    shadowOpacity: 1,
                    backgroundColor: AppColors.white.white,
                    marginHorizontal: 0,
                    marginTop: hv(7),
                    elevation: 3
                }}
            >
                {
                    props.image ?
                        <Image
                            source={props.image}
                            style={{
                                ...AppStyles.TextFieldImageStyle,
                                tintColor: iconColor
                            }}
                        /> :
                        null
                }
                <TextInput
                editable = {props.isDropDown ? false : true}
                pointerEvents = {props.isDropDown ? "none" : "auto"}
                value = {value}
                 keyboardType={props.type ? props.type : "default"}
                    style={{
                        zIndex: 0,
                        flex: 1,
                        ...AppStyles.TextFieldInputStyle2,
                        paddingLeft : normalized(8),
                        ...props.inputStyle,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                    }}
                    secureTextEntry = {props.isSecure ? secure : false}
                    placeholder={props.placeHolder}
                    placeholderTextColor={AppColors.green.appDarkGreen}
                    onChangeText={(text) => {
                        setValue(text)
                        setIconColor(text == "" ? AppColors.green.appDarkGreen : AppColors.blue.lightDarkBlue)
                    }}
                />
                           {
                props.isSecure ? 
                <TouchableWithoutFeedback
                onPress = {()=>{
                    console.log("tap")
                    setSecure(!secure)
                }}
                >
                    <Image
                    source = {secure == true ? AppImages.Authentication.hidePass : AppImages.Authentication.showPass}
                    style = {{
                        height : hv(20),
                        width : hv(20),
                        zIndex : 1,
                        position : "absolute",
                        right : AppHorizontalMargin,
                        resizeMode : "contain"
                    }}
                    />
                </TouchableWithoutFeedback> :
                null
            }
            </View>
        </View>
        </TouchableWithoutFeedback>
    )
}
export default AppTextField