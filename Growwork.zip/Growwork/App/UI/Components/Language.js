import React from "react"
import { useEffect } from "react"
import { useState } from "react"
import { View, SafeAreaView,Text } from "react-native"
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from "react-native-reanimated"
import SplashScreen from "react-native-splash-screen"
import { useDispatch, useSelector } from "react-redux"
import { setLang } from "../../Redux/actions/AppLogics"
import { AppRootStore } from "../../Redux/store/AppStore"
import { hv, normalized, ScreenSize } from "../Utils/AppConstants"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../Utils/AppStyles"
import CommonDataManager from "../Utils/CommonManager"
import AuthBtn from "./AuthBtn"
import CheckBox from "./Checkbox"
interface LanguageProps {
    onContinue : ()=>void,
    isStart? : boolean
}
const Language = (props: LanguageProps) => {
    const dispatch = useDispatch();
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const [selectedIndex, setSelectedIndex] = useState(-1)
    const translateY = useSharedValue(ScreenSize.height)
    const opacity = useSharedValue(0)
    useEffect(()=>{
        checkLang()
        animateView(true)
        setTimeout(() => {
            SplashScreen.hide()
        }, 200);
    },[])

    const checkLang = async() => {
        let index = await CommonDataManager.getSharedInstance().loadLang()
        if (index) {
            setSelectedIndex(index == "0" ? 0 : 1)
        }
        else {

        }
    }
    const animateView = (isOpen : boolean) => {
        translateY.value = withTiming(isOpen == true ? 0 : ScreenSize.height,{
            duration : 600
        })
        opacity.value = withTiming(isOpen == true ? 1 : 0,{
            duration : 600
        })
    }
    const animatedStyle = useAnimatedStyle(()=>{
        return {
            transform : [
                {
                    translateY : translateY.value
                }
            ],
            opacity : opacity.value
        }
    })
    return (
        <Animated.View
            style={[{
                ...AppStyles.MainStyle,
                justifyContent: "center",
                width: "100%",
                height: "100%",
                zIndex: 2,
                position: "absolute",
                elevation : 3,
                paddingHorizontal : AppHorizontalMargin,
                ...AppStyles.backgroundColor
            },animatedStyle]}
        >
            <SafeAreaView
            >
                <Text
                    style={{
                        ...AppStyles.TextCompactMediumStyle,
                        fontSize: normalized(21),
                        textAlign: "center",
                        marginBottom : hv(30),
                        ...AppStyles.textColor
                    }}
                >
                    {
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "selectLang")
                    }
                </Text>
                <CheckBox
                    setCheckBox={(number) => {
                        setSelectedIndex(number)
                    }}
                    index={0}
                    selected={selectedIndex == 0 ? true : false}
                    title={"English"}
                />
                <CheckBox
                    setCheckBox={(number) => {
                        setSelectedIndex(number)
                    }}
                    index={1}
                    selected={selectedIndex == 1 ? true : false}
                    title={"Hindi"}
                />
                <AuthBtn
                    btnStyle={{ marginTop: hv(30) }}
                    onClick={async() => {
                        console.log(selectedIndex)
                        if (selectedIndex == -1) {
                        }
                        else {
                            CommonDataManager.getSharedInstance().saveLang(selectedIndex)
                            dispatch(setLang(selectedIndex == 0 ? "english" : "hindi"))
                            props.onContinue()
                         animateView(false)
                        }
                    }}
                    title={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "continue")}
                />
            </SafeAreaView>
        </Animated.View>
    )
}
export default Language