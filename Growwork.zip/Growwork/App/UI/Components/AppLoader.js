import React from 'react';
import {View, ActivityIndicator} from 'react-native';
import {useSelector} from 'react-redux';
import { AppRootStore } from '../../Redux/store/AppStore';
import { AppColors } from '../Utils/AppConstants';
import { AppStyles } from '../Utils/AppStyles';
const AppLoader = () => {
  const appState = useSelector((appState: AppRootStore) => appState);
  return (
    <View
      style={[
        AppStyles.AppLoaderStyle,
        {
          zIndex: appState.AppReducer.isLoaderStart == true ? 1 : 0,
          backgroundColor: appState.AppReducer.isLoaderStart == true ? 'rgba(255,255,255,0.2)' : "transparent",
        },
      ]}>
        {
          appState.AppReducer.isLoaderStart == true ? 
          <View
          style = {AppStyles.AppIndicatorStyle}
          >
          <ActivityIndicator size="large" color={AppColors.blue.darkerBlue} />
          </View>
          : null
        }
    </View>
  );
};
export default AppLoader;
