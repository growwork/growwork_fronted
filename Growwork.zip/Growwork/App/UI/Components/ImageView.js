import axios from "axios"
import React, { useEffect, useState } from "react"
import { Image, ActivityIndicator, View } from "react-native"
import { AppColors, AppImages } from "../Utils/AppConstants"
const ImageView = ({ PlaceHolder, url, isLoader, style }) => {
    const [image, setImage] = useState()
    const [animate, stopAnimate] = useState(false)
    useEffect(() => {
    }, [])
    return (
        <View
            style={style}
        >
            <Image

                style={[style,{zIndex : 0}]}
                source={image ? image : { uri: url }}
                onLoadStart={() => stopAnimate(true)}
                onLoadEnd = {() => stopAnimate(false)}
                onError = {()=>setImage(AppImages.Home.serviceIcon)}
            />
            {animate == true ?
                    <View
                    style={{
                        justifyContent: "center",
                        alignItems: "center",
                        zIndex : 1,
                        position : "absolute",
                        top : 0,
                        bottom : 0,
                        left : 0,
                        right : 0
                    }}
                >
                    <ActivityIndicator size="small" color={AppColors.blue.lightDarkBlue} />
                </View> :
                null    
        }
        </View>
    )
}
export default ImageView