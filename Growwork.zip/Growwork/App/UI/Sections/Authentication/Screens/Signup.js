import React, { useEffect, useState } from "react"
import { View, SafeAreaView, ScrollView, Text, Image, TouchableWithoutFeedback, KeyboardAvoidingView } from "react-native"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import { HomeStylesWithProps } from "../../Home/Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { useDispatch, useSelector } from "react-redux"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import { AppImages, hv, normalized } from "../../../Utils/AppConstants"
import AuthBtn from "../../../Components/AuthBtn"
import AppTextField from "../../../Components/AppTextField"
import RadioBtn from "../../../Components/RadioBtn"
import { KeyboardAvoidingScrollView } from 'react-native-keyboard-avoiding-scroll-view';
import FilterModal from "../../../Components/FilterModal"
import DateTimePickerModal from "react-native-modal-datetime-picker";
const genderList = ["Male", "Female"]
const occupationList = ["Student", "Business", "Other"]

const Signup = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const [type, setType] = useState(0)
    const [showFilter, setShowFilter] = useState(false)
    const [filterType, setFilterType] = useState(-1)
    const [gender, setGender] = useState("")
    const [occupation1, setOccupation1] = useState("")
    const [occupation2, setOccupation2] = useState("")
    const [number, setNumber] = useState("")
    const [business1, setBusiness1] = useState("")
    const [business2, setBussiness2] = useState("")
    const [delivery, setDelivery] = useState(0)
    const [closingTime, setClosingTime] = useState()
    const [openingTime, setOpeningTime] = useState()

    const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

    const showDatePicker = () => {
        setDatePickerVisibility(true);
    };

    const hideDatePicker = () => {
        setDatePickerVisibility(false);
    };

    const handleConfirm = (date) => {
        console.warn("A date has been picked: ", date);
        hideDatePicker();
    };

    useEffect(() => {
    }, [])
    const setFilterItem = (index) => {
        if (filterType == 0) {
            setGender(genderList[index])
        }
        if (filterType == 1) {
            setOccupation1(occupationList[index])
        }
        if (filterType == 2) {
            setOccupation2(occupationList[index])
        }
        setFilterType(-1)
        setShowFilter(false)
    }
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "signup")
                }
                onBack={() => props.navigation.goBack()}
            />
            <View
                style={{
                    flex: 1,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                    paddingHorizontal: AppHorizontalMargin
                }}
            >
                <KeyboardAvoidingScrollView
                    showsVerticalScrollIndicator={false}
                    scrollEventThrottle={8}
                >
                    <View
                        style={{
                            ...HomeStylesWithProps(true).barStyle, justifyContent: "space-around", marginHorizontal: 0,
                            marginTop: 10,
                        }}
                    >
                        <RadioBtn
                            title={
                                CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Home", "services")
                            }
                            onPress={() => setType(0)}
                            selected={type == 0 ? true : false}
                        />
                        <RadioBtn
                            title={
                                CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Home", "business")
                            }
                            onPress={() => setType(1)}
                            selected={type == 1 ? true : false}
                        />
                    </View>
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "firstname")}

                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "lastname")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "email")}
                    />
                    <AppTextField
                        value={gender}
                        onDropDownSelect={() => {
                            setFilterType(0)
                            setShowFilter(true)
                        }}
                        isDropDown={true}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "gender")}
                    />
                    {type == 0 || type == 2 ?
                        <View>
                            <AppTextField
                                value={occupation1}
                                onDropDownSelect={() => {
                                    setFilterType(1)
                                    setShowFilter(true)
                                }}
                                isDropDown={true}
                                viewStyle={{
                                    marginTop: hv(10)
                                }}
                                placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "occupation")}
                            />
                            {
                                type == 0 ?

                                    <AppTextField
                                        value={occupation2}
                                        onDropDownSelect={() => {
                                            setFilterType(2)
                                            setShowFilter(true)
                                        }}
                                        isDropDown={true}
                                        viewStyle={{
                                            marginTop: hv(10)
                                        }}
                                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "occupationOptional")}
                                    /> : null
                            }
                        </View>
                        : null
                    }
                    {
                        type == 1 ?
                            <View>
                                <AppTextField
                                    viewStyle={{
                                        marginTop: hv(10)
                                    }}
                                    placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "businessName")}
                                />
                                <AppTextField
                                    viewStyle={{
                                        marginTop: hv(10)
                                    }}
                                    placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "businessType")}
                                />
                                <AppTextField
                                    viewStyle={{
                                        marginTop: hv(10)
                                    }}
                                    placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "businessType")}
                                />
                                <AppTextField
                                    type={"number-pad"}
                                    viewStyle={{
                                        marginTop: hv(10)
                                    }}
                                    placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "landlineNo")}
                                />
                                <Text
                                    style={{
                                        ...AppStyles.TextFieldInputStyle2, ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                        fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont, 16)),
                                        marginTop: hv(10),
                                    }}
                                >
                                    {CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "delivery")}
                                </Text>
                                <View
                                    style={{
                                        ...HomeStylesWithProps(true).barStyle, justifyContent: "space-around", marginHorizontal: 20,
                                        marginBottom: hv(0)
                                    }}
                                >
                                    <RadioBtn
                                        viewStyle={{
                                            marginVertical: 5
                                        }}
                                        title={
                                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "yes")
                                        }
                                        textStyle={{
                                            fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont, 12))
                                        }}
                                        onPress={() => setDelivery(0)}
                                        selected={delivery == 0 ? true : false}
                                    />
                                    <RadioBtn
                                        viewStyle={{
                                            marginVertical: 0
                                        }}
                                        title={
                                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "no")
                                        }
                                        textStyle={{
                                            fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont, 12))
                                        }}
                                        onPress={() => setDelivery(1)}
                                        selected={delivery == 1 ? true : false}
                                    />
                                </View>
                            </View>
                            : null
                    }
                    <AppTextField
                        value={""}
                        onDropDownSelect={() => {
                            showDatePicker()
                        }}
                        isDropDown={true}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "openingTime")}
                    />
                    <AppTextField
                        value={""}
                        onDropDownSelect={() => {
                            showDatePicker()
                        }}
                        isDropDown={true}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "closingTime")}
                    />
                    <AppTextField
                        type={"number-pad"}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "number")}
                    />
                    <AppTextField
                        type={"number-pad"}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "whatsappNo")}
                    />
                    <AppTextField
                        type={"number-pad"}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "identityNo")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "address")}
                    />
                    {
                        type == 0 ?
                            <AppTextField
                                viewStyle={{
                                    marginTop: hv(10)
                                }}
                                placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "area")}
                            /> :
                            null
                    }
                    {
                        type == 0 ?
                            <AppTextField
                                viewStyle={{
                                    marginTop: hv(10)
                                }}
                                placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "serviceDesc")}
                            /> :
                            <AppTextField
                                viewStyle={{
                                    marginTop: hv(10)
                                }}
                                placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "businessDesc")}
                            />
                    }
                    <AuthBtn
                        btnStyle={{ marginTop: hv(30) }}
                        onClick={async () => {
                        }}
                        title={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "signup")}
                    />
                </KeyboardAvoidingScrollView>
            </View>
            {
                showFilter == true ?
                    <FilterModal
                        data={filterType == 0 ? genderList : filterType == 1 ? occupationList : filterType == 2 ? occupationList : occupationList}
                        onClose={() => setShowFilter(false)}
                        onSelect={(index) => {
                            setFilterItem(index)
                        }}
                    /> : null
            }
            <DateTimePickerModal
                isVisible={isDatePickerVisible}
                mode="time"
                onConfirm={handleConfirm}
                onCancel={hideDatePicker}
            />
        </View>
    )
}
export default Signup