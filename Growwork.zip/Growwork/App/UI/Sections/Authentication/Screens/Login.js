import React, { useEffect, useState } from "react"
import { View, SafeAreaView, ScrollView, Text, Image,TouchableWithoutFeedback, KeyboardAvoidingView } from "react-native"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import { HomeStylesWithProps } from "../../Home/Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { useDispatch, useSelector } from "react-redux"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import { AppImages, hv, normalized, ScreenNames } from "../../../Utils/AppConstants"
import AuthBtn from "../../../Components/AuthBtn"
import AppTextField from "../../../Components/AppTextField"
import {KeyboardAvoidingScrollView} from 'react-native-keyboard-avoiding-scroll-view';
const Login = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    useEffect(() => {
    }, [])
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "login")
                }
                onBack={() => props.navigation.goBack()}
            />
            <View
                style={{
                    flex: 1,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                    paddingHorizontal: AppHorizontalMargin
                }}
            >
                <KeyboardAvoidingScrollView
                    contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingBottom: 50 }}
                >
                    <Image
                        source={AppImages.Authentication.appLogo[selector.AppReducer.currentTheme]}
                        style={{
                            ...AppStyles.AppLogo,
                        }}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(40)
                        }}
                        image={AppImages.Authentication.emailGreen}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "email")}

                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(20)
                        }}
                        image={AppImages.Authentication.lockGreen}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "password")}
                        isSecure={true}
                    />
                    <AuthBtn
                        btnStyle={{ marginTop: hv(30) }}
                        onClick={async () => {
                        }}
                        title={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "login")}
                    />
                    <TouchableWithoutFeedback
                        onPress={() => {
                            props.navigation.navigate(ScreenNames.Authentication.Signup)
                        }}
                    >
                        <View
                            style={{
                                ...AppStyles.CombineTextStyle,
                                marginTop: 20
                            }}
                        >
                            <Text
                                style={{
                                    ...AppStyleWithProps(selector.AppReducer.currentTheme).forgetPassText,
                                    fontSize :normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14))
                                }}
                            >
                                {
                                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "noAccount")
                                }
                                <Text
                                    style={{
                                        ...AppStyles.linkBtnStyle,
                                    }}
                                >
                                    {
                                        CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "joinNow")
                                    }
                                </Text>
                            </Text>
                        </View>
                    </TouchableWithoutFeedback>
                </KeyboardAvoidingScrollView>
            </View>
        </View>
    )
}
export default Login