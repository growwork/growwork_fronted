import React, { useState } from "react"
import { FlatList, View, SafeAreaView } from "react-native"
import { useDispatch, useSelector } from "react-redux"
import { AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import SearchBar from "../Components/SearchBar"
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import { CityList } from "../../../Utils/CityList"
import SimpleCheckBox from "../../../Components/SimpleCheckBox"
import { DrawerStylesWithProps } from "../../../../Navigation/Styles/DrawerStyles"
const CitiesList = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const dispatch = useDispatch()
    const [search, setSearch] = useState(false)
    const [list,setList] = useState(CityList)
    const filterList = (text)=>{
        console.log(text)
        let newList = []
        if (text == "") {
            setList(CityList)
            return
        }
        for (let i = 0;i<CityList.length;i++) {
            if (CityList[i].toLowerCase().includes(text.toLowerCase())){
                newList.push(CityList[i])
            }
        }
        setList(newList)
    }
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Profile", "profile")
                }
                onBack={() => props.navigation.goBack()}
            />
            <SearchBar
                onClick={() => {
                    setSearch(!search)
                }}
                showGoBtn = {false}
                onChange = {(text)=>filterList(text)}
            />
            <View
                style={{
                    ...AppStyles.MainStyle,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor
                }}
            >
                <FlatList
                showsVerticalScrollIndicator = {false}
                    data={list}
                    keyExtractor={(item, index) => `${index}`}
                    renderItem={({ item, index }) => {
                        return (
                            <View>
                                <SimpleCheckBox
                                    title={item}
                                    index={index}
                                    selected={false}
                                    setCheckBox={() => {
                                        props.route.params.onChangeCity(item)
                                    }}
                                />
                                <View
                                style = {{
                                    ...DrawerStylesWithProps(selector.AppReducer.currentTheme).seperatorStyle
                                }}
                                />
                            </View>
                        )
                    }}
                />
                <SafeAreaView />
            </View>
        </View>
    )
}
export default CitiesList