import React, { useState } from "react"
import { FlatList, View, SafeAreaView, ScrollView, Image, Text } from "react-native"
import { useDispatch, useSelector } from "react-redux"
import { AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import SearchBar from "../Components/SearchBar"
import SearchTab from "../Components/SearchTab"
import SingleHomeItem from "../Components/SingleHomeItem"
import TopBar from "../Components/TopBar"
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import ProfileTopView from "../Components/ProfileTopView"
import { AppImages, hv, normalized } from "../../../Utils/AppConstants"
import Animated from 'react-native-reanimated';
import BottomSheet from 'reanimated-bottom-sheet';
import ShareContactView from "../Components/ShareContactView"
import AuthBtn from "../../../Components/AuthBtn"
const ItemProfile = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const dispatch = useDispatch()
    const sheetRef = React.useRef(null);
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Profile", "profile")
                }
                onBack={() => props.navigation.goBack()}
            />
            <ProfileTopView />
            <View
                style={{
                    ...AppStyles.MainStyle,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                    paddingHorizontal: normalized(20),
                }}
            >
                <ScrollView
                >
                    <View
                        style={{
                            ...AppStyles.HoriCommonStyle,
                            justifyContent: "flex-start",
                            marginTop: 30
                        }}
                    >
                        <Image
                            source={AppImages.Home.telephone}
                            style={{
                                ...HomeStylesWithProps(selector.AppReducer.currentTheme).profileDetailItemImageStyle
                            }}
                        />
                        <Text
                            style={{
                                ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                ...AppStyles.TextMediumStyle,
                                fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                                paddingLeft: normalized(20)
                            }}
                        >
                            03084008055
                        </Text>
                    </View>
                    <View
                        style={{
                            ...AppStyles.HoriCommonStyle,
                            justifyContent: "flex-start",
                            marginTop: hv(20)
                        }}
                    >
                        <Image
                            source={AppImages.Home.mobile}
                            style={{
                                ...HomeStylesWithProps(selector.AppReducer.currentTheme).profileDetailItemImageStyle
                            }}
                        />
                        <Text
                            style={{
                                ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                ...AppStyles.TextMediumStyle,
                                fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                                paddingLeft: normalized(20)
                            }}
                        >
                            03084008055
                        </Text>
                    </View>
                    <View
                        style={{
                            ...AppStyles.HoriCommonStyle,
                            justifyContent: "flex-start",
                            marginTop: hv(20)
                        }}
                    >
                        <Image
                            source={AppImages.Home.whatsapp}
                            style={{
                                ...HomeStylesWithProps(selector.AppReducer.currentTheme).profileDetailItemImageStyle
                            }}
                        />
                        <Text
                            style={{
                                ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                ...AppStyles.TextMediumStyle,
                                fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                                paddingLeft: normalized(20)
                            }}
                        >
                            03084008055
                        </Text>
                    </View>
                    <View
                        style={{
                            ...AppStyles.HoriCommonStyle,
                            justifyContent: "flex-start",
                            marginTop: hv(20)
                        }}
                    >
                        <Image
                            source={AppImages.Home.clock}
                            style={{
                                ...HomeStylesWithProps(selector.AppReducer.currentTheme).profileDetailItemImageStyle
                            }}
                        />
                        <Text
                            style={{
                                ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                ...AppStyles.TextLightStyle,
                                fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                                paddingLeft: normalized(20)
                            }}
                        >
                            (Mon-Sun)11:00am to 9:00pm
                        </Text>
                    </View>
                    <View
                        style={{
                            ...AppStyles.HoriCommonStyle,
                            justifyContent: "flex-start",
                            marginTop: hv(20)
                        }}
                    >
                        <Image
                            source={AppImages.Home.pencilNotes}
                            style={{
                                ...HomeStylesWithProps(selector.AppReducer.currentTheme).profileDetailItemImageStyle
                            }}
                        />
                        <Text
                            style={{
                                ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                ...AppStyles.TextLightStyle,
                                fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                                paddingLeft: normalized(20)
                            }}
                        >
                            We make your celebration memorable
                        </Text>
                    </View>
                    <AuthBtn
                        btnStyle={{ marginTop: hv(30) }}
                        onClick={() => {
                            sheetRef.current.snapTo(2)
                        }}
                        title={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Profile", "share")}
                    />
                </ScrollView>
                <SafeAreaView />
            </View>
            <BottomSheet
                borderRadius={30}
                ref={sheetRef}
                snapPoints={[0, 0, 200]}
                borderRadius={10}
                renderContent={() => {
                    return (
                        <ShareContactView />
                    )
                }}
            />

        </View>
    )
}
export default ItemProfile