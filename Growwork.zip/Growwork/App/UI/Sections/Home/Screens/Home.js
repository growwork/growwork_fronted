import React, { useEffect, useState } from "react"
import { FlatList, View, SafeAreaView, Keyboard, Platform } from "react-native"
import { useDispatch, useSelector } from "react-redux"
import { AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import SearchBar from "../Components/SearchBar"
import SearchTab from "../Components/SearchTab"
import SingleHomeItem from "../Components/SingleHomeItem"
import TopBar from "../Components/TopBar"
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import SearchSingleItem from "../Components/SearchSingleItem"
import AdsListView from "../Components/AdsListView"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import { ScreenNames } from "../../../Utils/AppConstants"
import { check, request, PERMISSIONS, RESULTS, openSettings, requestNotifications } from 'react-native-permissions';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import GetLocation from 'react-native-get-location';
import { setUserRequestLoc, startLoader } from "../../../../Redux/actions/AppLogics"
import Geocoder from "react-native-geocoding"
import CommonDataManager from "../../../Utils/CommonManager"
import { servicesRequest } from "../../../../Network/Services/HomService"
const Home = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const dispatch = useDispatch()
    const [search, setSearch] = useState(false)
    const [showAd, setShowAd] = useState(true)
    const [city, setCity] = useState(CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Home", "city"))
    const [searchText,setSearchText] = useState("")
    const [serviceList, setServiceList] = useState([])
    useEffect(() => {
        if (Platform.OS == "android") {
            androidLocationEnabler()
        }
        else {
            checkLocation()
        }
        Keyboard.addListener('keyboardDidShow', _keyboardDidShow)
        Keyboard.addListener('keyboardDidHide', _keyboardDidHide)
        return {
        }
    }, [])
    const serviceListRequest = async(params) => {
        dispatch(startLoader(true))
       return servicesRequest(params).catch(() => {
            console.log("error")
        })
        .then((response)=>{
            console.log(response)
            if (response.code == 200) {
                let list = []
                for (let i=0;i<response.data.length;i++) {
                    let index = list.findIndex((item)=>item.desc == response.data[i].description)
                    if (index == -1) {
                        let obj = {
                            desc : response.data[i].description,
                            list : [response.data[i]]
                        }
                        list.push(obj)
                    }
                    else {
                        let obj = list[index]
                        let newList = obj.list
                        newList.push(response.data[i])
                        obj.list = newList
                        list[index = obj]
                    }
                }
                setServiceList(list)
            }
        })
            .finally(() => dispatch(startLoader(false)))
    }
    const androidLocationEnabler = async () => {
        RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
            interval: 10000,
            fastInterval: 5000,
        })
            .then((data) => {
            }).finally(() => {
                getLocation()
            })
            .catch((err) => {
                let params = {
                    type: "services",
                    city: "Mumbai",
                    search: ""
                }
                serviceListRequest(params)
            });
    }

    const getLocation = () => {
        GetLocation.getCurrentPosition({
            enableHighAccuracy: true,
            timeout: 3000,

        })
            .then(location => {
                Geocoder.from({
                    lat: location.latitude,
                    lng: location.longitude,
                }).then(data => {
                    let result = data.results[0];
                    var locCity = result.address_components[
                        result.address_components.length - 3
                    ]
                    setCity(locCity.long_name)
                    let params = {
                        type: "services",
                        city: locCity.long_name,
                        search: ""
                    }
                    serviceListRequest(params)
                })
            })
            .catch(error => {
                const { code, message } = error;
                console.warn(code, message);
                let params = {
                    type: "services",
                    city: "Mumbai",
                    search: ""
                }
                serviceListRequest(params)
            });
    };
    const checkLocation = () => {
        check(Platform.OS == "ios" ? PERMISSIONS.IOS.LOCATION_WHEN_IN_USE : PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION)
            .then((result) => {
                switch (result) {
                    case RESULTS.UNAVAILABLE:
                        console.log('This feature is not available (on this device / in this context)');
                        break;
                    case RESULTS.DENIED:
                        getLocation()
                        break;
                    case RESULTS.LIMITED:
                        console.log('The permission is limited: some actions are possible');
                        break;
                    case RESULTS.GRANTED:
                        getLocation()
                        break;
                    case RESULTS.BLOCKED:
                        if (selector.AppReducer.isLocRequestCall == false) {
                            dispatch(setUserRequestLoc(true))
                            CommonDataManager.getSharedInstance().showPopUpWithOptions("", "Location permission is denied do you like to give permission?", "Yes", "No", (type) => {
                                if (type == 0) {
                                    openSettings().catch(() => console.warn('cannot open settings'));
                                }
                                else {
                                    let params = {
                                        type: "services",
                                        city: "Mumbai",
                                        search: ""
                                    }
                                    serviceListRequest(params)
                                }
                            })
                        }
                        else {
                            let params = {
                                type: "services",
                                city: "Mumbai",
                                search: ""
                            }
                            serviceListRequest(params)
                        }
                        break;
                }
            })
            .catch((error) => {
                // …
            });
    }

    const _keyboardDidShow = () => {
        if (Platform.OS == "android") {
            setShowAd(false)
        }
    }
    const _keyboardDidHide = () => {
        setShowAd(true)
    }
    const changeCity = (newCity) => {
        setCity(newCity)
        props.navigation.navigate(ScreenNames.Home.Home)
        setSearchText("")
        let params = {
            type: "services",
            city: newCity,
            search: ""
        }
        serviceListRequest(params)
    }
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <TopBar
                cityTitle={city}
                onCity={() => {
                    props.navigation.push(ScreenNames.Home.City, {
                        onChangeCity: newCity => changeCity(newCity)
                    })
                }}
                onMenu={() => {
                    props.navigation.toggleDrawer()
                }}
            />
            <SearchBar
            value = {searchText}
                onChange={(text) => {
                    setSearchText(text)
                    console.log(text)
                }}
                onClick={() => {
                    if (searchText != "") {
                        let params = {
                            type: "services",
                            city: city,
                            search: searchText
                        }
                        serviceListRequest(params)
                    }
                    // setSearch(!search)
                }}
                showGoBtn={true}
            />
            <SearchTab />
            <View
                style={{
                    ...AppStyles.MainStyle,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor
                }}
            >
                {search == false ?
                    <View
                        style={{
                            flex: 1
                        }}
                    >
                        <FlatList
                            showsVerticalScrollIndicator={false}
                            data={serviceList}
                            columnWrapperStyle={{ flex: 1, justifyContent: "space-around" }}
                            numColumns={3}
                            keyExtractor={(item, index) => `${index}`}
                            renderItem={({item}) => {
                                return (
                                    <SingleHomeItem
                                    serviceObj = {item}
                                    onClick = {()=>{
                                        console.log("tap")
                                        if (item.list.length > 1) {
                                        }
                                        else {
                                            props.navigation.push(ScreenNames.Home.ItemProfile)
                                        }
                                    }}
                                    />
                                )
                            }}
                        />

                    </View> :
                    null
                }
                {
                    search == true ?
                        <View
                            style={{
                                flex: 1
                            }}
                        >
                            <FlatList
                                showsVerticalScrollIndicator={false}
                                data={[1, 2, 3, 4, 5, 6, 7, 8, 12, 232, 22, 2, 2, 2, 2, 2,]}
                                keyExtractor={(item, index) => `${index}`}
                                renderItem={() => {
                                    return (
                                        <SearchSingleItem
                                            onPress={() => props.navigation.push(ScreenNames.Home.ItemProfile)}
                                        />
                                    )
                                }}
                            />

                        </View> : null
                }
                {/* <View
                    style={{
                        opacity: showAd == true ? 1 : 0
                    }}
                >
                    <AdsListView />
                </View> */}
            </View>
        </View>
    )
}
export default Home