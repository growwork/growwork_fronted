import React from "react"
import { View, Text, Image, TouchableWithoutFeedback } from "react-native"
import { useSelector } from "react-redux";
import { HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore";
import { AppHorizontalMargin, AppStyleWithProps } from "../../../Utils/AppStyles";
import { hv, normalized, ScreenSize } from "../../../Utils/AppConstants";
import CommonDataManager from "../../../Utils/CommonManager";
const AdSingleItem = ({ obj }) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <View
            style={{
                flexDirection: "row",
                paddingVertical: hv(5),
                width : ScreenSize.width,
                paddingHorizontal : AppHorizontalMargin,
            }}
        >
            <View
                style={{
                    width: "30%",
                    alignItems: "center",
                    height : hv(130),

                }}
            >
                <Image
                    style={{
                        height: 60,
                        width: 60,
                        resizeMode: "contain",
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                        borderRadius: 8
                    }}
                    source={obj.image}
                />
                <Text
                numberOfLines = {2}
                    style={{
                        ...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),

                    }}
                >
                    Grow work
                </Text>
            </View>
            <View
                style={{
                    flex: 1,
                    alignItems: "flex-start",
                    paddingLeft: normalized(5),
                    paddingTop: hv(10),
                    justifyContent : "center"
                }}
            >
                <Text
               numberOfLines = {2}
                    style={{
                        ...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        textAlign: "left",
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,18)),
                    }}
                >
                    {obj.name}
                </Text>
                <Text
                    numberOfLines={2}
                    style={{
                        ...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                        textAlign: "left"
                    }}
                >
                    {`${obj.name} Burlington Clinic Pvt. Ltd.`}
                </Text>
                <Text
                    numberOfLines={2}
                    style={{
                        ...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                        textAlign: "left"
                    }}
                >
                    Dr Kehar Singh Marg, Muktsar, Muktsar - 152026, Kotakpura Bye Pass Chowk
                </Text>
                <Text
                    numberOfLines={2}
                    style={{
                        ...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)),
                        alignSelf : "flex-end",
                        marginTop : 2,
                        paddingRight : 6
                    }}
                >
                    03084008055
                </Text>
            </View>
        </View>
    )
}
export default AdSingleItem