import React from "react"
import { TouchableWithoutFeedback, View, Image, Text, TextInput } from "react-native"
import { useSelector } from "react-redux";
import { HomeStylesWithProps } from "../Styles/HomeStyles";
import { AppRootStore } from "../../../../Redux/store/AppStore";
import ShareBtn from "./ShareBtn";
import CommonDataManager from "../../../Utils/CommonManager";
import { AppImages } from "../../../Utils/AppConstants";
import { AppHorizontalMargin } from "../../../Utils/AppStyles";
const ShareContactView = () => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).shareContactSheetStyle,
                justifyContent: "space-around",
                alignItems: "center",
                flexDirection : "row",
                paddingHorizontal : AppHorizontalMargin
            }}
        >
            <ShareBtn
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Profile", "addContact")
                }
                image={AppImages.Home.addContact}
                onClick={() => console.log("press")}
            />
            <ShareBtn
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Profile", "share")
                }
                image={AppImages.Home.message}
                onClick={() => console.log("press")}
            />
            <ShareBtn
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Profile", "phone")
                }
                image={AppImages.Home.phoneWhite}
                onClick={() => console.log("press")}
            />
        </View>
    )
}
export default ShareContactView