import React from "react"
import { TouchableWithoutFeedback, View, Image, Text, TextInput } from "react-native"
import { AppColors, normalized } from "../../../Utils/AppConstants"
import { AppStyles } from "../../../Utils/AppStyles"
import { useSelector } from "react-redux";
import { HomeStylesWithProps } from "../Styles/HomeStyles";
import { AppRootStore } from "../../../../Redux/store/AppStore";
import CommonDataManager from "../../../Utils/CommonManager";
const ShareBtn = ({image, onClick, title}) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <TouchableWithoutFeedback
        onPress = {()=>onClick()}
        >
            <View
                style={{
                    justifyContent: "center",
                    alignItems: "center",
                    flex : 1
                }}
            >
                <View
                    style={{
                        justifyContent: "center",
                        alignItems: "center",
                        height: 50,
                        width: 50,
                        ...AppStyles.commonShadowStyle,
                        borderRadius: 8,
                        backgroundColor: AppColors.black.black,
                        overflow : "hidden",
                    }}
                >
                    <Image
                        style={{
                            ...HomeStylesWithProps(1).itemImageStyle,
                            height : 40,
                            width : 40
                        }}
                        source={image}
                    />
                </View>
                <Text
                    style={{
                        ...AppStyles.TextSemiBoldStyle,
                        color: AppColors.black.black,
                        fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                        marginTop : 5
                    }}
                >
                    {title}
                </Text>
            </View >
        </TouchableWithoutFeedback>
    )
}
export default ShareBtn