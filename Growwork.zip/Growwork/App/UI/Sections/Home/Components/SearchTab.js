import React, { useState } from "react"
import { TouchableWithoutFeedback, View, Image, Text, TextInput } from "react-native"
import { useSelector } from "react-redux";
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore";
import { AppColors, AppImages, hv, normalized } from "../../../Utils/AppConstants";
import { AppStyles } from "../../../Utils/AppStyles";
import CommonDataManager from "../../../Utils/CommonManager";
import CheckBox from "../../../Components/Checkbox";
const SearchTab = ({ onClick }) => {
    const [selectedIndex, setSelectedIndex] = useState(0)
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <View
            style={{ ...HomeStylesWithProps(true).barStyle, justifyContent: "space-around",marginHorizontal :0 }}
        >
            <TouchableWithoutFeedback
                onPress={() => setSelectedIndex(0)}
            >
                <View
                    style={{ ...AppStyles.HoriCommonStyle }}
                >
                    <Image
                        source={selectedIndex == 0 ? AppImages.Home.radioSelected : AppImages.Home.radioUnselected}
                    />
                    <Text
                        style={{ ...HomeStyles.goStyle, color: AppColors.white.white, marginLeft: normalized(10) }}
                    >
                        {
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Home", "services")
                        }
                    </Text>
                </View>
            </TouchableWithoutFeedback>
            <TouchableWithoutFeedback
                onPress={() => setSelectedIndex(1)}
            >
                <View
                    style={{ ...AppStyles.HoriCommonStyle }}
                >
                    <Image
                        source={selectedIndex == 1 ? AppImages.Home.radioSelected : AppImages.Home.radioUnselected}
                    />
                    <Text
                        style={{ ...HomeStyles.goStyle, color: AppColors.white.white, marginLeft: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,10)) }}
                    >
                        {
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Home", "business")
                        }
                    </Text>
                </View>
            </TouchableWithoutFeedback>
        </View>
    )
}
export default SearchTab