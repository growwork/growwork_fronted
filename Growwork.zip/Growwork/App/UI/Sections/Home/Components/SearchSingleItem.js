import React from "react"
import { View, Text, TouchableWithoutFeedback, Image } from "react-native"
import { useDispatch, useSelector } from "react-redux";
import { AppRootStore } from "../../../../Redux/store/AppStore";
import { AppColors, AppImages, normalized } from "../../../Utils/AppConstants";
import { AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles";
import CommonDataManager from "../../../Utils/CommonManager";
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles";
const SearchSingleItem = ({onPress}) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const dispatch = useDispatch()
    return (
        <TouchableWithoutFeedback
        onPress = {()=>onPress()}
        >
            <View
                style={{
                    ...HomeStylesWithProps(selector.AppReducer.currentTheme).searchSingleItemStyle
                }}
            >
                <View
                    style={{
                        ...HomeStylesWithProps(selector.AppReducer.currentTheme).searchInnerViewStyle
                    }}
                >
                    <View>
                        <Text
                            style={{
                                ...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,
                                ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)),

                            }}
                        >
                            Slice of veyo
                        </Text>
                        <Text
                            style={{
                                ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                                ...AppStyles.TextSimpleStyle,
                                fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,12)),
                            }}
                        >
                            {`12 N Main St\nVeyo UT 84782`}
                        </Text>
                        <Text
                            style={{
                                ...AppStyles.TextSemiBoldStyle,
                                color: AppColors.blue.lightDarkBlue,
                                fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,14)),
                            }}
                        >
                            435-218-7291
                        </Text>
                    </View>
                </View>
                <Text
                style = {{
                    fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,12)),

                }}
                >
                    Quality At its best,Made with pride,We had the opportunity to embark
                </Text>
            </View>
        </TouchableWithoutFeedback>
    )
}
export default SearchSingleItem