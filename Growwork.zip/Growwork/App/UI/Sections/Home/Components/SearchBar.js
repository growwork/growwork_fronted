import React from "react"
import { TouchableWithoutFeedback, View, Image, Text, TextInput } from "react-native"
import { useSelector } from "react-redux";
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore";
import { AppColors, AppImages, hv, normalized } from "../../../Utils/AppConstants";
import { AppStyles } from "../../../Utils/AppStyles";
import CommonDataManager from "../../../Utils/CommonManager";
const SearchBar = ({ onClick,showGoBtn,onChange,value }) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <View
            style={{ ...HomeStylesWithProps(true).barStyle, justifyContent: "flex-start" }}
        >
            <View
            style = {{
                ...HomeStyles.searchBarStyle
            }}
            >
                <Image
                source = {AppImages.Home.search}
                style = {{
                    height : hv(20),
                    width : hv(20),
                    resizeMode : "contain"
                }}
                />
                <TextInput
                value = {value}
                placeholder = {
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Home", "search")
                }
                style = {{
                    ...HomeStyles.searchTextFieldStyle,
                    fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)),
                }}
                onChangeText = {(text)=>onChange(text)}
                />
            </View>
            {
                showGoBtn == true ?

            
            <TouchableWithoutFeedback
            onPress = {()=>onClick()}
            >
                <View
                    style={{
                        ...HomeStyles.searchBtnStyle
                    }}
                >
                    <Text
                    style = {{
                        ...HomeStyles.goStyle,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)),
                    }}
                    >
                        {
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Home", "go")
                        }
                    </Text>
                </View>
            </TouchableWithoutFeedback>
:
null
}
       </View>
    )
}
export default SearchBar