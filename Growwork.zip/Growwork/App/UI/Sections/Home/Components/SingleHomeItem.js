import React from "react"
import { View,TouchableOpacity, Image, Text } from "react-native"
import { useSelector } from "react-redux"
import { AppImages, normalized } from "../../../Utils/AppConstants"
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { AppStyleWithProps } from "../../../Utils/AppStyles"
import CommonDataManager from "../../../Utils/CommonManager"
import { IMAGE_BASE_URL } from "../../../../Network/Urls"
import ImageView from "../../../Components/ImageView"
const SingleHomeItem = ({serviceObj,onClick}) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <TouchableOpacity
        onPress = {()=>{
            console.log("tap")
            onClick()
        }}
        >
            <View
            style = {HomeStyles.itemStyle}
            >
                {/* <Image
                source = {{uri : IMAGE_BASE_URL + serviceObj.list[0].icon_name}}
                style = {HomeStylesWithProps(selector.AppReducer.currentTheme).itemImageStyle}
                /> */}
                <ImageView
                style = {HomeStylesWithProps(selector.AppReducer.currentTheme).itemImageStyle}
                url = {IMAGE_BASE_URL + serviceObj.list[0].icon_name}
                isLoader = {true}
                PlaceHolder = {AppImages.Home.serviceIcon}
                />
                <Text
                style = {{...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                    fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16))
                }}
                >
                    {serviceObj.list[0].description}
                </Text>
            </View>
        </TouchableOpacity>
    )
}
export default SingleHomeItem