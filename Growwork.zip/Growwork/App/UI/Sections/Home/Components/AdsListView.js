import React from "react"
import { View, Text, Image, TouchableWithoutFeedback } from "react-native"
import { useSelector } from "react-redux";
import { HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore";
import AdSingleItem from "./AdSingleItem";
import { addList, ScreenSize } from "../../../Utils/AppConstants";
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import { AppHorizontalMargin } from "../../../Utils/AppStyles";
import { DrawerStylesWithProps } from "../../../../Navigation/Styles/DrawerStyles";

const AdsListView = () => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).adsListStyle,
                marginBottom : 15
            }}
        >
            <View
            style = {{...DrawerStylesWithProps(selector.AppReducer.currentTheme).seperatorStyle}}
            />
            <SwiperFlatList
            style = {{
            }}
                autoplay = {true}
                autoplayDelay={3}
                autoplayLoopKeepAnimation = {true}
                autoplayLoop = {true}
                index={0}
                showPagination = {false}
                data={addList}
                renderItem={({ item }) => (
                    <AdSingleItem
                    obj={item}
                />
                )}
            />
        </View>
    )
}
export default AdsListView