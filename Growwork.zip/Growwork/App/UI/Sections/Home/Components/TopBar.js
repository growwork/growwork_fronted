import React from "react"
import { TouchableWithoutFeedback, View, Image, Text } from "react-native"
import { useSelector } from "react-redux";
import { HomeStylesWithProps } from "../Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore";
import { AppColors, AppImages, hv, normalized } from "../../../Utils/AppConstants";
import { AppStyles } from "../../../Utils/AppStyles";
import CommonDataManager from "../../../Utils/CommonManager";
const TopBar = ({ isCity, onMenu, onCity, cityTitle }) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <View
            style={{ ...HomeStylesWithProps(isCity).barStyle }}
        >
            <View
                style={{
                    position: "absolute",
                    left: 0,
                    right: 10,
                    justifyContent: "center",
                    alignItems: "center"
                }}
            >
                <Text
                    style={{
                        ...AppStyles.TextCompactMediumStyle,
                        fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont, 24)),
                        color: AppColors.white.white,
                        textAlign: "center",
                    }}
                >
                    GROW WORK
                </Text>
            </View>
            <TouchableWithoutFeedback
                onPress={() => onMenu()}
            >
                <Image
                    source={AppImages.Drawer.menu}
                    style={{
                        height: 25,
                        width: 25,
                        resizeMode: "contain"
                    }}
                />
            </TouchableWithoutFeedback>
            <TouchableWithoutFeedback
                    onPress={() => onCity()}
                >
            <View
                style={{
                    width: normalized(100),
                    justifyContent: "center",
                    alignItems: "flex-end"
                }}
            >

                    <Text
                        numberOfLines={1}
                        style={{
                            ...AppStyles.TextCompactMediumStyle,
                            color: AppColors.white.white,
                            textAlign: "center",
                            fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont, 14)),
                            borderWidth: 1.5,
                            borderColor: AppColors.white.white,
                            borderRadius: normalized(5),
                            padding: 5
                        }}
                    >
                        {
                            cityTitle ? cityTitle : ""
                        }
                    </Text>
            </View>
            </TouchableWithoutFeedback>
        </View>
    )
}
export default TopBar