import React from "react"
import { View, Text, TouchableWithoutFeedback, Image } from "react-native"
import { useSelector } from "react-redux";
import { AppRootStore } from "../../../../Redux/store/AppStore";
import { addList, AppColors, AppImages, hv, normalized } from "../../../Utils/AppConstants";
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles";
import CommonDataManager from "../../../Utils/CommonManager";
import { HomeStyles, HomeStylesWithProps } from "../Styles/HomeStyles";
const ProfileTopView = () => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).profileCardStyle,
                paddingVertical: hv(10),
                paddingHorizontal: AppHorizontalMargin / 2,
                marginHorizontal : 15,
                marginBottom : AppHorizontalMargin
            }}
        >
            <View
                style={{
                    height: 70,
                    width: 70,
                    justifyContent: "center",
                    alignSelf: "center",
                    alignItems: "center",
                    borderRadius: 35,
                    borderColor: AppColors.blue.darkerBlue,
                    borderWidth: 1.5
                }}
            >
                <Image
                    source={addList[2].image}
                    style={{
                        width: 65,
                        height: 65,
                        resizeMode: "contain",
                    }}
                />
            </View>
            <Text
                style={{
                    ...AppStyles.TextSemiBoldStyle,
                    textAlign: "center",
                    marginTop: 5,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                    fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,18)),

                }}
            >
                IHope Society
            </Text>
            <Text
                style={{
                    ...AppStyles.TextMediumStyle,
                    textAlign: "center",
                    marginTop: 5,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                    fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,16)),
                }}
            >
                Growwork(owner)
            </Text>
            <View
                style={{
                    ...AppStyles.HoriCommonStyle,
                    justifyContent: "flex-start",
                    marginTop: 10
                }}
            >
                <Image
                    style={{
                        ...HomeStyles.pinStyle,
                    }}
                    source={AppImages.Home.locationPin}
                />
                <Text
                    style={{
                        ...AppStyles.TextSimpleStyle,
                        textAlign: "center",
                        marginLeft: 10,
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,12)),

                    }}
                >
                    5201 Blue Lagoon Drive Suite 300, Miami
                </Text>
            </View>
            <View
                style={{
                    ...AppStyles.HoriCommonStyle,
                    justifyContent: "flex-start",
                    marginTop: 5
                }}
            >
                <Image
                    style={{
                        ...HomeStyles.pinStyle,
                    }}
                    source={AppImages.Home.mailPin}
                />
                <Text
                    style={{
                        ...AppStyles.TextSimpleStyle,
                        textAlign: "center",
                        marginLeft: 10,
                        ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,12)),

                    }}
                >
                    armughangul15@gmail.com
                </Text>
            </View>
        </View>
    )
}
export default ProfileTopView