import { Platform, StyleSheet } from 'react-native';
import { AppColors, hv, normalized } from '../../../Utils/AppConstants';
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from '../../../Utils/AppStyles';
export const HomeStyles = StyleSheet.create({
    searchBtnStyle : {
        height : hv(45),
        width : hv(45),
        justifyContent : "center",
        alignItems : "center",
        backgroundColor : AppColors.white.white,
        borderRadius : normalized(8),
        ...AppStyles.commonShadowStyle
    },
    goStyle : {
        ...AppStyles.TextSemiBoldStyle,
    },
    searchBarStyle : {
        height : hv(45),
        flex : 1,
        backgroundColor : AppColors.white.white,
        borderRadius : normalized(8),
        ...AppStyles.commonShadowStyle,
        marginRight : normalized(10),
        flexDirection : "row",
        marginRight : normalized(10),
        alignItems : "center",
        paddingHorizontal : normalized(10)
    },
    searchTextFieldStyle : {
    height : hv(40),
    flex : 1,
    ...AppStyles.TextCompactRegularStyle,
    fontSize : normalized(16),
    marginLeft : normalized(8),
    padding : 0
    },
    itemStyle : {
        justifyContent : "center",
        alignItems : "center",
        marginBottom : hv(10),
        marginTop : hv(5),
    },
    pinStyle : {
        height : 20,
        width : 20,
        resizeMode : "contain"
    }
})
export const HomeStylesWithProps = (props) => StyleSheet.create({
    barStyle : {
        alignItems : "center",
        marginHorizontal : AppHorizontalMargin,
        justifyContent : "space-between",
        flexDirection : "row",
        marginVertical : hv(10)
    },
    homeBack : {
        flex : 1,
        backgroundColor : props == 0 ? AppColors.blue.lightDarkBlue : AppColors.black.lightishBlack
    },
    itemImageStyle : {
        height : hv(60),
        width : hv(60),
        resizeMode : "contain",
        tintColor : props == 0 ? AppColors.black.black : AppColors.white.white
    },
    itemTextStyle : {
        ...AppStyles.TextCompactMediumStyle,
        textAlign : "center"
    },
    searchSingleItemStyle : {
        marginHorizontal : AppHorizontalMargin,
        borderRadius : 8,
        paddingHorizontal : normalized(12),
        backgroundColor : props == 0 ? AppColors.white.white : AppColors.black.black,
        marginVertical : hv(10),
        shadowColor : props == 0 ? AppColors.shadowColor.lightBlack : AppColors.white.withShadowLight,
        shadowOffset : {width : 0,height : 0},
        shadowOpacity : 1 ,
        shadowRadius : 2,
        elevation : 5,
        paddingVertical : hv(10)
    },
    searchInnerViewStyle : {
        justifyContent : "space-between",
        flexDirection : "row"
    },
    labelStyle : {
        justifyContent : "center",
        alignItems : "center",
        width : normalized(35),
        height : hv(22),
        borderRadius : normalized(13),
        backgroundColor : AppColors.red.darkRed,
        borderColor : AppColors.blue.lightDarkBlue,
        borderWidth : 3
    },
    imageStyle : {
        height : 30,
        width : 30,
        resizeMode : "contain",
        tintColor : props == 0 ? AppColors.black.black : AppColors.white.white
    },
    adsListStyle : {
    },
    profileCardStyle : {
        backgroundColor :props == 0 ? AppColors.white.white : "transparent",
        shadowColor : AppColors.white.withShadowLight,
        shadowOffset : {width : 0,height : 0},
        shadowOpacity : 1 ,
        shadowRadius : 4,
        elevation : 5,
        marginHorizontal : AppHorizontalMargin,
        borderTopStartRadius : 8,
        borderTopRightRadius : 8,
        borderColor : AppColors.white.white,
        borderWidth : props == 0 ? 0 : 0.5
    },
    profileDetailItemImageStyle : {
        height : normalized(30),
        width : normalized(30),
        resizeMode : "contain",
        tintColor : props == 0 ? AppColors.black.black : AppColors.white.white
    },
    shareContactSheetStyle : {
        height : 200,
        backgroundColor : AppColors.white.white,
        ...AppStyles.commonShadowStyle
    }
})