import React from "react"
import {View,ScrollView,SafeAreaView,Text,TouchableWithoutFeedback} from "react-native"
import { ScreenSize,hv, normalized, AppColors } from "../../../Utils/AppConstants"
import { AppHorizontalMargin, AppStyles, } from "../../../Utils/AppStyles"
import CommonDataManager from "../../../Utils/CommonManager"
import { AppStrings } from "../../../Utils/AppStrings"
import AuthBtn from "../../../Components/AuthBtn"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { useSelector } from "react-redux"
interface TermsPopUpProps {
    title : string,
    onSelect : (type : number)=>void
}
const TermsPopUp = (props : TermsPopUpProps) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    return(
        <View
        style = {{
            height : "100%",
            width : "100%",
            position : "absolute",
            justifyContent : "flex-end",
            zIndex : 1,
        }}
        >
        <TouchableWithoutFeedback
        onPress = {()=>{
        }}
        >
        <View
        style = {{
            height : "100%",
            width : "100%",
            position : "absolute",
            justifyContent : "flex-end",
            zIndex : 0,
            elevation : 3,
            alignSelf : "center",

        }}
        >
         </View>
        </TouchableWithoutFeedback>
        <View
        style = {{
            flex : 1,
            justifyContent : "flex-start",
            borderRadius : 8,
            elevation : 3,
            marginHorizontal : AppHorizontalMargin,
            marginTop : 20,
            zIndex : 1,
            backgroundColor : "rgba(255,255,255,1)",
        }}
        >
            <View
            style = {{
                flex : 1,
                justifyContent : "flex-start",
                backgroundColor : "white",
                borderRadius : 8,
            }}
            >
           <SafeAreaView/>
              <ScrollView
                showsVerticalScrollIndicator = {false}
                >
                  <Text
                style = {{...AppStyles.HeaderTitleStyle,
                alignSelf : "center",
                paddingTop : 20,
                }}
                >
                    {
                        CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage,"Auth","terms")
                    }
                </Text>
                    <Text
                    style = {{
                        ...AppStyles.TextSimpleStyle,
                        fontSize : normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont,18)),
                        color : AppColors.blue.darker,
                        paddingTop : 20,
                        alignSelf : "center",
                        paddingHorizontal : AppHorizontalMargin
                    }}
                    >
                        {AppStrings.loremIpsum}
                        </Text>
                        </ScrollView>
            </View>
             <View
                style = {{
                    ...AppStyles.bottomBtnViewStyle,
                    marginVertical : 20,
                    flexDirection : "row",
                    justifyContent : "space-between"
                }}
                >
              <AuthBtn
                btnStyle = {{marginHorizontal : 0,width : ScreenSize.width/2 - AppHorizontalMargin - 10,height : hv(50),backgroundColor : AppColors.green.appDarkGreen}}
                onClick = {()=>props.onSelect(0)}
                title = {CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage,"Auth","cancel")}
                />
                    <AuthBtn
                btnStyle = {{marginHorizontal : 0,width : ScreenSize.width/2 - AppHorizontalMargin - 10,height : hv(50)}}
                onClick = {()=>props.onSelect(1)}
                title = {CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage,"Auth","ok")}
                />
                </View>
            <SafeAreaView/>
            </View>
        </View>
    )
}
export default TermsPopUp