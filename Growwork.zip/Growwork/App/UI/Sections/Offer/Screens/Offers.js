import React, { useEffect, useState, useRef } from "react"
import { View, SafeAreaView, ScrollView, Text, Image, TouchableWithoutFeedback, KeyboardAvoidingView, PermissionsAndroid } from "react-native"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import { HomeStylesWithProps } from "../../Home/Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { useDispatch, useSelector } from "react-redux"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import { AppColors, AppImages, hv, normalized } from "../../../Utils/AppConstants"
import AuthBtn from "../../../Components/AuthBtn"
import AppTextField from "../../../Components/AppTextField"
import RadioBtn from "../../../Components/RadioBtn"
import { KeyboardAvoidingScrollView } from 'react-native-keyboard-avoiding-scroll-view';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import Animated from "react-native-reanimated"
import OfferSingleItem from "../Components/OfferSingleItem"
import { AnimatedFlatList, AnimationType } from "flatlist-intro-animations"
const Offers = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const [image, setImage] = useState();
    const [midPoint, setMidPoint] = useState(0)
    const [currentOffset, setCurrentOffset] = useState(0)
    const scrollViewRef = React.useRef(null);
    useEffect(() => {
    }, [])
    // Functions
    const setScaleValue = () => {
    }
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Container", "offer")
                }
                onBack={() => props.navigation.goBack()}
            />
            <View
                onLayout={(layout) => {
                    console.log(selector.AppReducer.bottomSpace.bottom)
                    let layoutHeight = layout.nativeEvent.layout.height
                    setMidPoint(layoutHeight / 2)
                }}
                style={{
                    flex: 1,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                }}
            >
                <AnimatedFlatList
                    keyExtractor={(item, index) => `${index}`}
                    data={[1, 2, 3, 4, 5, 6, 7, 8, 9]}
                    renderItem={({ item }) => {
                        return (
                            <OfferSingleItem />
                        )
                    }}
                    animationType={AnimationType.Rotate}
                    animationDuration={1000}
                />

            </View>
        </View >
    )
}
export default Offers