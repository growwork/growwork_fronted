import React, { useEffect, useState } from "react"
import { View, SafeAreaView, ScrollView, Text, Image, TouchableWithoutFeedback, KeyboardAvoidingView, PermissionsAndroid } from "react-native"
import Animated, { useAnimatedStyle, useSharedValue, withSpring, withTiming } from "react-native-reanimated"
import { AppColors, normalized } from "../../../Utils/AppConstants"
import { AppHorizontalMargin } from "../../../Utils/AppStyles"
const OfferSingleItem = ({})=> {
    useEffect(()=>{
    },[])
    const ViewStyle = useAnimatedStyle(()=>{
        return {
            height : 180,
            backgroundColor : AppColors.blue.dark,
            borderRadius : 8
        }
    })
    return(
        <View
        style = {{
            height : 200,
            justifyContent : "center",
            marginHorizontal : AppHorizontalMargin,
            overflow : "hidden"
        }}
        >
            <Animated.View
            style = {ViewStyle}
            >
            </Animated.View>
        </View>
    )
}
export default OfferSingleItem