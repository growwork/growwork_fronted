import React, { useEffect, useState } from "react"
import { View, SafeAreaView, ScrollView, Text, Image, TouchableWithoutFeedback, KeyboardAvoidingView, PermissionsAndroid } from "react-native"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import { HomeStylesWithProps } from "../../Home/Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { useDispatch, useSelector } from "react-redux"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import { AppColors, AppImages, hv, normalized } from "../../../Utils/AppConstants"
import AuthBtn from "../../../Components/AuthBtn"
import AppTextField from "../../../Components/AppTextField"
import RadioBtn from "../../../Components/RadioBtn"
import { KeyboardAvoidingScrollView } from 'react-native-keyboard-avoiding-scroll-view';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
const AdForm = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const [image, setImage] = useState();

    useEffect(() => {
    }, [])
    // Functions
    const checkCameraOptions = () => {
        CommonDataManager.getSharedInstance().showPopUpWithOptions(
            'Profile',
            'Please select options',
            'Camera',
            'Gallery',
            type => {
                if (type == 0) {
                    if (Platform.OS == 'android') {
                        requestCameraPermission();
                    } else {
                        launchCamera(
                            {
                                mediaType: 'photo',
                                quality: 1,
                            },
                            data => {
                                if (data.assets) {
                                    setImage(data.assets[0].uri);
                                }
                            },
                        );
                    }
                }
                if (type == 1) {
                    launchImageLibrary(
                        {
                            mediaType: 'photo',
                            quality: 1,
                        },
                        data => {
                            console.log(data);
                            if (data.assets) {
                                setImage(data.assets[0].uri);
                            }
                        },
                    );
                }
            },
        );
    };
    const requestCameraPermission = async () => {
        try {
            const granted = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.CAMERA,
                {
                    title: 'Cool Photo App Camera Permission',
                    message:
                        'MeetMyCar App needs access to your camera ' +
                        'so you can take awesome pictures.',
                    buttonNeutral: 'Ask Me Later',
                    buttonNegative: 'Cancel',
                    buttonPositive: 'OK',
                },
            );
            if (granted === PermissionsAndroid.RESULTS.GRANTED) {
                console.log('You can use the camera');

                launchCamera(
                    {
                        mediaType: 'photo',
                        quality: 1,
                    },
                    data => {
                        if (data.assets) {
                            setImage(data.assets[0].uri);
                        }
                    },
                );
            } else {
                console.log('Camera permission denied');
            }
        } catch (err) {
            console.warn(err);
        }
    };

    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Container", "ads")
                }
                onBack={() => props.navigation.goBack()}
            />
            <View
                style={{
                    flex: 1,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                    paddingHorizontal: AppHorizontalMargin
                }}
            >
                <KeyboardAvoidingScrollView
                    showsVerticalScrollIndicator={false}
                    scrollEventThrottle={8}
                >
                    <View
                        style={{
                            backgroundColor: AppColors.white.white,
                            height: normalized(100),
                            width: normalized(100),
                            borderRadius: normalized(50),
                            justifyContent: 'center',
                            alignItems: 'center',
                            marginTop: 30,
                            alignSelf: "center"
                        }}>
                        <TouchableWithoutFeedback
                            onPress={() => {
                                checkCameraOptions();
                            }}>
                            <View
                                style={{
                                    height: normalized(90),
                                    width: normalized(90),
                                    borderRadius: normalized(45),
                                    backgroundColor: 'white',
                                    borderWidth: 4,
                                    borderColor: AppColors.white.white,
                                    shadowColor: AppColors.shadowColor.lightBlack,
                                    shadowOffset: { width: 0, height: 0 },
                                    shadowOpacity: 1,
                                    shadowRadius: 3,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    elevation: 3,
                                }}>
                                <View
                                    style={{
                                        overflow: 'hidden',
                                        height: normalized(85),
                                        width: normalized(85),
                                        borderRadius: normalized(42.5),
                                    }}>
                                    <Image
                                        style={{
                                            resizeMode: "stretch",
                                            width: normalized(85),
                                            height: normalized(85),
                                        }}
                                        source={image == undefined ? AppImages.Home.dummyUser : { uri: image }}
                                    />
                                </View>
                            </View>
                        </TouchableWithoutFeedback>
                    </View>
                    <Text
                        numberOfLines={2}
                        style={{
                            ...HomeStylesWithProps(selector.AppReducer.currentTheme).itemTextStyle,
                            ...AppStyleWithProps(selector.AppReducer.currentTheme).textColor,
                            textAlign: "center",
                            fontSize: normalized(CommonDataManager.getSharedInstance().setFontSize(selector.AppReducer.currentFont, 18)),
                            marginTop: hv(8)
                        }}
                    >
                        {CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Ads", "selectLogo")}
                    </Text>
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(20)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Ads", "enterName")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(20)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Ads", "enterDesc")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(20)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Ads", "enterAddress")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(20)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Ads", "enterNo")}
                    />
                    <AuthBtn
                        btnStyle={{ marginTop: hv(30) }}
                        onClick={async () => {
                        }}
                        title={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "continue")}
                    />
                </KeyboardAvoidingScrollView>
            </View>
        </View >
    )
}
export default AdForm