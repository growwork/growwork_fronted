import React, { useEffect, useState } from "react"
import { View, SafeAreaView, ScrollView, Text } from "react-native"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import { HomeStyles, HomeStylesWithProps } from "../../Home/Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { useDispatch, useSelector } from "react-redux"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import { hv, normalized } from "../../../Utils/AppConstants"
import RadioBtn from "../../../Components/RadioBtn"
import AuthBtn from "../../../Components/AuthBtn"
import { setCurrentFont, setLang, setTheme } from "../../../../Redux/actions/AppLogics"
const Setting = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const dispatch = useDispatch()
    const [lang, setLanguage] = useState(-1)
    const [theme, setcurrentTheme] = useState(-1)
    const [font, setFont] = useState(-1)
    useEffect(() => {
        setLanguage(selector.AppReducer.currentLanguage == "english" ? 0 : 1)
        setcurrentTheme(selector.AppReducer.currentTheme == 1 ? 1 : 0)
        setFont(selector.AppReducer.currentFont)
    }, [])
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "settings")
                }
                onBack={() => props.navigation.goBack()}
            />
            <View
                style={{
                    flex: 1,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                    paddingHorizontal: AppHorizontalMargin
                }}
            >
                <ScrollView
                    contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}
                >
                    <Text
                        style={
                            AppStyleWithProps(selector.AppReducer.currentTheme).settingSubHeadingStyle
                        }
                    >
                        {
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "selectLang")
                        }
                    </Text>
                    <RadioBtn
                        title={
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "english")
                        }
                        onPress={() => setLanguage(0)}
                        selected={lang == 0 ? true : false}
                    />
                    <RadioBtn
                        title={
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "hindi")
                        }
                        onPress={() => setLanguage(1)}
                        selected={lang == 1 ? true : false}
                    />
                    <Text
                        style={
                            AppStyleWithProps(selector.AppReducer.currentTheme).settingSubHeadingStyle
                        }
                    >
                        {
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "changeTheme")
                        }
                    </Text>
                    <RadioBtn
                        title={
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "light")
                        }
                        onPress={() => setcurrentTheme(0)}
                        selected={theme == 0 ? true : false}
                    />
                    <RadioBtn
                        title={
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "dark")
                        }
                        onPress={() => setcurrentTheme(1)}
                        selected={theme == 1 ? true : false}
                    />
                    <Text
                        style={
                            AppStyleWithProps(selector.AppReducer.currentTheme).settingSubHeadingStyle
                        }
                    >
                        {
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "changeFont")
                        }
                    </Text>
                    <RadioBtn
                        title={
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "small")
                        }
                        onPress={() => setFont(0)}
                        selected={font == 0 ? true : false}
                    />
                    <RadioBtn
                        title={
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "medium")
                        }
                        onPress={() => setFont(1)}
                        selected={font == 1 ? true : false}
                    />
                    <RadioBtn
                        title={
                            CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Settings", "large")
                        }
                        onPress={() => setFont(2)}
                        selected={font == 2 ? true : false}
                    />
                    <AuthBtn
                        btnStyle={{ marginTop: hv(30) }}
                        onClick={async () => {
                            CommonDataManager.getSharedInstance().saveFont(font)
                            CommonDataManager.getSharedInstance().saveLang(lang)
                            dispatch(setLang(lang == 0 ? "english" : "hindi"))
                            dispatch(setTheme(theme))
                            dispatch(setCurrentFont(font))
                            CommonDataManager.getSharedInstance().saveTheme(selector, theme)
                        }}
                        title={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "continue")}
                    />
                </ScrollView>
            </View>
        </View>
    )
}
export default Setting