import React, { useEffect, useState } from "react"
import { View, SafeAreaView, ScrollView, Text, Image, TouchableWithoutFeedback, KeyboardAvoidingView } from "react-native"
import AppTopBar from "../../../Components/AppTopBar"
import CommonDataManager from "../../../Utils/CommonManager"
import { HomeStylesWithProps } from "../../Home/Styles/HomeStyles"
import { AppRootStore } from "../../../../Redux/store/AppStore"
import { useDispatch, useSelector } from "react-redux"
import { DrawerNavigationProp } from "@react-navigation/drawer"
import { AppHorizontalMargin, AppStyles, AppStyleWithProps } from "../../../Utils/AppStyles"
import { AppImages, hv, normalized } from "../../../Utils/AppConstants"
import AuthBtn from "../../../Components/AuthBtn"
import AppTextField from "../../../Components/AppTextField"
import RadioBtn from "../../../Components/RadioBtn"
import { KeyboardAvoidingScrollView } from 'react-native-keyboard-avoiding-scroll-view';
import FilterModal from "../../../Components/FilterModal"
const genderList = ["Male", "Female"]
const occupationList = ["Student", "Business", "Other"]

const Career = (props: DrawerNavigationProp) => {
    const selector = useSelector((AppState: AppRootStore) => AppState);
    const [type, setType] = useState(2)
    const [showFilter, setShowFilter] = useState(false)
    const [filterType, setFilterType] = useState(-1)
    const [gender, setGender] = useState("")
    const [occupation1, setOccupation1] = useState("")
    const [occupation2, setOccupation2] = useState("")
    const [number, setNumber] = useState("")
    const [business1, setBusiness1] = useState("")
    const [business2, setBussiness2] = useState("")
    const [delivery, setDelivery] = useState(0)
    useEffect(() => {
    }, [])
    const setFilterItem = (index) => {
        if (filterType == 0) {
            setGender(genderList[index])
        }
        if (filterType == 1) {
            setOccupation1(occupationList[index])
        }
        if (filterType == 2) {
            setOccupation2(occupationList[index])
        }
        setFilterType(-1)
        setShowFilter(false)
    }
    return (
        <View
            style={{
                ...HomeStylesWithProps(selector.AppReducer.currentTheme).homeBack
            }}
        >
            <SafeAreaView />
            <AppTopBar
                title={
                    CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "career")
                }
                onBack={() => props.navigation.goBack()}
            />
            <View
                style={{
                    flex: 1,
                    ...AppStyleWithProps(selector.AppReducer.currentTheme).backgroundColor,
                    paddingHorizontal: AppHorizontalMargin
                }}
            >
                <KeyboardAvoidingScrollView
                    showsVerticalScrollIndicator={false}
                    scrollEventThrottle={8}
                >
                    <View
                        style={{
                            ...HomeStylesWithProps(true).barStyle, justifyContent: "space-around", marginHorizontal: 0,
                            marginTop: 10
                        }}
                    >
                    </View>
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "firstname")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "lastname")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "email")}
                    />
                    <AppTextField
                        value={gender}
                        onDropDownSelect={() => {
                            setFilterType(0)
                            setShowFilter(true)
                        }}
                        isDropDown={true}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "gender")}
                    />
                    {type == 0 || type == 2 ?
                        <View>
                            <AppTextField
                                value={occupation1}
                                onDropDownSelect={() => {
                                    setFilterType(1)
                                    setShowFilter(true)
                                }}
                                isDropDown={true}
                                viewStyle={{
                                    marginTop: hv(10)
                                }}
                                placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "occupation")}
                            />
                        </View>
                        : null
                    }
                    
                    <AppTextField
                        type={"number-pad"}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "number")}
                    />
                    <AppTextField
                        type={"number-pad"}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "whatsappNo")}
                    />
                    <AppTextField
                        type={"number-pad"}
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "identityNo")}
                    />
                    <AppTextField
                        viewStyle={{
                            marginTop: hv(10)
                        }}
                        placeHolder={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "address")}
                    />
                    <AuthBtn
                        btnStyle={{ marginTop: hv(30) }}
                        onClick={async () => {
                        }}
                        title={CommonDataManager.getSharedInstance().getTranslation(selector.AppReducer.currentLanguage, "Auth", "continue")}
                    />
                </KeyboardAvoidingScrollView>
            </View>
            {
                showFilter == true ?
                    <FilterModal
                        data={filterType == 0 ? genderList : filterType == 1 ? occupationList : filterType == 2 ? occupationList : occupationList}
                        onClose={() => setShowFilter(false)}
                        onSelect={(index) => {
                            setFilterItem(index)
                        }}
                    /> : null
            }
        </View>
    )
}
export default Career