import { Platform, StyleSheet } from 'react-native';
import { AppColors, AppFonts, hv, normalized } from './AppConstants';
export const AppHorizontalMargin = normalized(20)
export const AppStyles = StyleSheet.create({
    MainStyle : {
        flex : 1,
    },
    AppLogo : {
      width : hv(200),
      height : hv(150),
      resizeMode : "contain",
      alignSelf : "center"
    },
    AppLoaderStyle: {
      height: '100%',
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      position: 'absolute',
      elevation : 3
    },
    AppIndicatorStyle : {
      height : 70,
      width : 70,
      justifyContent : "center",
      alignItems : "center",
      borderRadius : 8,
      backgroundColor : "white",
      shadowColor : AppColors.shadowColor.lightBlack,
      shadowOffset : {width : 0,height : 0},
      shadowOpacity : 1,
      shadowRadius : 5,
      elevation : 8
    },
    HeaderTitleStyle : {
      fontFamily : AppFonts.sfCompactDisplaySemiBold,
      fontSize : normalized(24),
      color : AppColors.blue.darkerWithOp,
    },

    CheckBoxViewStyle : {
      flexDirection : "row",
      justifyContent : "flex-start",
      alignItems : "center",
      marginVertical : 15
    },
    TextFieldStyle : {
        marginHorizontal : AppHorizontalMargin,
        alignItems : "center",
        flexDirection : "row",
        height : hv(50),
        backgroundColor : "rgba(255,255,255,0.65)",
        borderRadius : 8,
        paddingHorizontal : 15,
    },
    TextBoldStyle: {
        fontFamily: AppFonts.PoppinBold,
        includeFontPadding: false,
      },
      TextLightStyle: {
        fontFamily: AppFonts.PoppinsLight,
        includeFontPadding: false,
      },
      TextSemiBoldStyle: {
        fontFamily: AppFonts.PoppinsSemiBold,
        includeFontPadding: false,
      },
      TextSimpleStyle: {
        fontFamily: AppFonts.PoppinsRegular,
        includeFontPadding: false,
      },
      TextMediumStyle: {
        fontFamily: AppFonts.PoppinMedium,
        includeFontPadding: false,
      },
      TextBaskerVilleReg : {
        fontFamily: AppFonts.BaskervilleReg,
        includeFontPadding: false,
      },
      TextBaskerVilleSemiBold : {
        fontFamily: AppFonts.BaskervilleSemiBold,
        includeFontPadding: false,
      },
      TextCompactMediumStyle : {
        fontFamily : AppFonts.sfCompactDisplayMedium,
        includeFontPadding: false,
      },
      TextCompactSemiboldStyle : {
        fontFamily : AppFonts.sfCompactDisplaySemiBold,
        includeFontPadding: false,
      },
      TextCompactRegularStyle : {
        fontFamily : AppFonts.sfCompactDisplayRegular,
        includeFontPadding: false,
      },
      TextCompactLightStyle : {
        fontFamily : AppFonts.sfCompactDisplayLight,
        includeFontPadding: false,

      },
      TextFieldImageStyle : {
          marginLeft : 10,
          height : hv(20),
          width : 20,
          resizeMode : "contain",
      },
      TextFieldInputStyle : {
          fontFamily : AppFonts.PoppinsLight,
          fontSize : normalized(14),
          paddingLeft : 20,
          color : AppColors.blue.dark,
          flex : 1
      },
      TextFieldInputStyle2 : {
        fontFamily : AppFonts.sfCompactDisplayRegular,
        paddingLeft : 20,
        color : AppColors.blue.dark,
    },
      AuthBtnStyle : {
          backgroundColor : AppColors.blue.lightDarkBlue,
          justifyContent : "center",
          alignItems : "center",
          borderRadius : 8,
          marginHorizontal : AppHorizontalMargin,
          height : hv(55)
      },
      AuthBtnTextStyle : {
          fontFamily : AppFonts.sfCompactDisplayMedium,
          color : "white"
      },
      CombineTextStyle : {
        marginHorizontal : AppHorizontalMargin,
        flexDirection : "row",
        justifyContent : "center",
        alignItems : "center"
      },
      linkBtnStyle : {
        fontFamily : AppFonts.PoppinsSemiBold,
        color : AppColors.blue.lightDarkBlue,
      },
      HoriCommonStyle : {
        alignItems : "center",
        flexDirection : "row",
        justifyContent : "center"
      },


      blackSeperator : {
        width : normalized(0.7),
        backgroundColor : AppColors.black.black,
      },
      commonShadowStyle : {
        shadowColor : AppColors.shadowColor.lightBlack,
        shadowOffset : {width : 0,height : 0},
        shadowOpacity : 1 ,
        shadowRadius : 2,
        elevation : 5,
      },
})
export const AppStyleWithProps = (props : any) => StyleSheet.create({
  HomeSingleItem : {
    backgroundColor : AppColors.white.white,
    width : props,
    borderRadius : normalized(10),
    shadowRadius : 2,
    shadowColor : AppColors.shadowColor.lightBlack,
    shadowOpacity : 1,
    shadowOffset : {width : -0.5,height : -0.5},
    elevation : 4,
    marginBottom : hv(12),
  },
  socialBtnStyle : {
    height : hv(44),
    width : hv(44),
  },
  overlayViewStyle : {
    width : "100%",
    height : "100%",
    zIndex : props,
    position : "absolute",
    elevation : 3
  },
  backgroundColor : {
    backgroundColor : props == 0 ? AppColors.grey.bgGrey : AppColors.black.black
  },
  textColor : {
    color : props == 0 ? AppColors.black.black : AppColors.white.white
  },
  seperatorsColor : {
    backgroundColor : props == 0 ? AppColors.black.black : AppColors.white.white
  },
  settingSubHeadingStyle : {
    fontFamily : AppFonts.sfCompactDisplayMedium,
    fontSize: normalized(21),
    textAlign: "center",
    marginVertical : hv(10),
    color : props == 0 ? AppColors.black.black : AppColors.white.white
  },
  forgetPassText : {
    alignSelf : "flex-end",
    marginTop : 10,
    marginHorizontal : AppHorizontalMargin,
    color : props == 0 ? AppColors.black.black : AppColors.white.white
  },
})