import React from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert, Platform } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ScreenNames, ScreenProps } from './AppConstants';
import { AppStrings } from './AppStrings';
import { setCartItems } from '../../Redux/actions/AppLogics';
export default class CommonDataManager {
    static shared: any = null;
    _translations = [];
    _currentLanguage = "en";
    _screenStack: ScreenProps = null
    selector: any = null
    dispatch: any = null
    static getSharedInstance() {
        if (CommonDataManager.shared == null) {
            console.log('CommonDataManager - no shared object')
            CommonDataManager.shared = new CommonDataManager();
            CommonDataManager.shared.setup();
        }
        return CommonDataManager.shared;
    }
    setup = async () => {
        console.log('CommonDataManager - init')
        try {
            this._translations = [];
            const localTranslaionsData = require("./translation.json");
            this._translations = localTranslaionsData;
        } catch (e) {
            console.log('CommonDataManager -- init ', e)
        }
    }

    setReduxReducer = (select: any, dispatch: any) => {
        this.selector = select
        this.dispatch = dispatch
    }
    getTranslation = (language: any, screen: any, labelString: String) => {
        var languageDic = this._translations[language]
        var mainScreen = languageDic[screen];
        if (mainScreen !== undefined) {
            var translatedLabel = mainScreen[labelString];
            if (translatedLabel !== undefined) {
                return translatedLabel;
            }
        }
    }
    showPopUp = (title: string, message: string) => {
        Alert.alert(
            title,
            message,
            [{ text: 'OK', onPress: () => console.log('OK Pressed') }],
            { cancelable: true },
        );
    };
    showPopUpWithOptions = (title, message,leftTitle,rightTitle, okPress) => {
        Alert.alert(
            title,
            message,
            [{ text: leftTitle, onPress: () => okPress(0) },
            { text: rightTitle, onPress: () => okPress(1) }
            ],
            { cancelable: false },
        );
    };
    validateEmail = (email: string) => {
        let validEmailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

        if (validEmailRegex.test(email) == false) {
            return false
        }
        else {
            return true
        }
    }
    setScreenStack = (props: ScreenProps) => {
        this._screenStack = props
    }
    saveLang = async (index: number) => {
        let saveResult = await AsyncStorage.setItem("lang", JSON.stringify(index))
        return saveResult
    }
    loadLang = async () => {
        let stringResult = await AsyncStorage.getItem("lang")
        if (stringResult) {
            return stringResult
        }
        else {
            return null
        }
    }
    saveTheme = async (selector, index: number) => {
        this.selector = selector
        let saveResult = await AsyncStorage.setItem("theme", JSON.stringify(index))
        return saveResult
    }
    getTheme = async () => {
        let stringResult = await AsyncStorage.getItem("theme")
        if (stringResult) {
            return stringResult
        }
        else {
            return null
        }
    }
    saveFont = async (index: number) => {
        let saveResult = await AsyncStorage.setItem("font", JSON.stringify(index))
        return saveResult
    }
    getFont = async () => {
        let stringResult = await AsyncStorage.getItem("font")
        if (stringResult) {
            let font = JSON.parse(stringResult)
            return font
        }
        else {
            return null
        }
    }
    saveTerms = async (index: number) => {
        let saveResult = await AsyncStorage.setItem("terms", JSON.stringify(index))
        return saveResult
    }
    loadTerms = async () => {
        let stringResult = await AsyncStorage.getItem("terms")
        if (stringResult) {
            return stringResult
        }
        else {
            return null
        }
    }
    saveLoginUser = async (user: UserViewModel) => {
        var jsonUser = JSON.stringify(user)
        let saveResult = await AsyncStorage.setItem(AppStrings.userAsynKey, jsonUser)
        console.log(saveResult)
        return saveResult
    }
    // getNewToken = async(userId : string)=> {
    //     console.log(userId)
    //   let params = {
    //       user_id : userId
    //   }
    //   let response : ApiResponseHandler<UserViewModel> = await refreshTokenRequest<UserViewModel>(
    //       params
    //     ).catch((err) => {
    //       CommonDataManager.getSharedInstance().showPopUp(AppStrings.errorTitle,err)
    //     }).finally(()=>{
    //     });
    //   let saveData = await this.saveLoginUser(response.data)
    //     console.log(response.data)
    //     return response.data
    // }
    loadLoginUser = async () => {
        let stringUser = await AsyncStorage.getItem(AppStrings.userAsynKey)
        if (stringUser) {
            let user: UserViewModel = JSON.parse(stringUser)
            return user
        }
        else {
            return null
        }
    }

    logoutUser = async () => {
        let removeUser = await AsyncStorage.removeItem(AppStrings.userAsynKey)
        return this._screenStack.navigation.reset({
            index: 0,
            routes: [{ name: ScreenNames.Authentication.Login }]
        })
    }
    setFontSize = (current, size) => {
        switch (current) {
            case 0:
                return size - 2
            case 1:
                return size
            case 2:
                return size + 2
            default:
                return size
        }
    }
}