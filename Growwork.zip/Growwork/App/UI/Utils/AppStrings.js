export const AppStrings = {
    dummyLoremIpsum : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras at libero vitae velit posuere aliquet in vitae diam. Aliquam eget metus ligula. In ipsum justo,lobortis id suscipit a, tincidunt ac metus. ",
    userAsynKey : "loginUser",
    numberAsyncKey : "numberSave",
    errorTitle : "",
    formEmptyError : "Please fill all the fields.",
    emailError : "Please enter a valid email.",
    numberError : "Please enter a valid number.",
    code : "Please enter a valid code.",
    codeSent : "Code sent successfully",
    loremIpsum : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
}