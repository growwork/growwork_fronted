import { StackScreenProps } from "@react-navigation/stack";
import React from "react"
import { Dimensions, Platform, PixelRatio } from "react-native";
import { useSelector } from "react-redux";
import { AppHorizontalMargin } from "./AppStyles";
import CommonDataManager from "./CommonManager";
export const platformVersion = Platform.Version;
export type ScreenProps = StackScreenProps<any, any>;
export const ScreenSize = Dimensions.get("window")

const templateWidth = 375;
const templateHeight = 812;
const widthRatio = ScreenSize.width / templateWidth;
const heightRatio = ScreenSize.height / templateHeight;

export const normalized = (value: number) => {
    return PixelRatio.roundToNearestPixel(value * widthRatio);
}
export const hv = (value: number) =>
    PixelRatio.roundToNearestPixel(value * heightRatio);
    let value = normalized(20) * 2
export const horizontalScreenWithMargin = ScreenSize.width - value
export const ScreenNames = {
    Authentication: {
        Login: "Login",
        Signup: "Signup",
        Setting: "Setting",
    },
    Container: "Container",
    Home: {
        Home: "Home",
        ItemProfile: "ItemProfile",
        HomeStack : "HomeStack",
        City : "CityList"
    },
    Profile : {
        Profile : "Profile",
    },
    Settings : {
        Settings : "Settings"
    },
    Career : {
        career : "Career"
    },
    Ad : {
        ad : "AdForm"
    },
    Offer : {
        offers : "Offers"
    }
}
export const AppColors = {
    blue: {
        lightDarkBlue: "#3F74BA",
        darkerBlue: "#203A5D",
        dark: "#1C2440",
    },
    white: {
        white: "#FFFFFF",
        withShadowLight: Platform.OS == "ios" ? "rgba(255,255,255,0.16)" : "rgba(255,255,255,0.26)",
        lightWhite : "rgba(255,255,255,0.8)",
        lightishWhite : "rgba(255,255,255,0.05)"
    },
    black: {
        black: "#000000",
        lightBlack: "rgba(0,0,0,0.32)",
        withShadowLight: Platform.OS == "ios" ? "rgba(0,0,0,0.16)" : "rgba(0,0,0,0.26)",
        textColor: "#414141",
        lightOP: "rgba(0,0,0,0.5)",
        lightishBlack : "rgba(0,0,0,0.9)"
    },
    shadowColor: {
        lightBlack: "rgba(0,0,0,0.15)",
        darkBlack: "rgba(0,0,0,1)"
    },
    grey: {
        bgGrey: "#F0F0F0",
        seperatorLight: "#D8D8D8",
        textDarkGrey : "#6D6E72",
        borderDark : "#979797"
    },
    red: {
        darkRed: "#E81C37",
        deleteRed: "#F22008"
    },
    green: {
        appGreen: "#5CB700",
        appDarkGreen: "#14210E",
        appDarkGreenWithOP: "rgba(20,33,14,0.3)",
        lightGreen: "#7BC05B",
        lightishGreen : "#38E699"
    },
    lightBlue: "#2E818F"
}
export const AppImages = {
    Authentication: {
        unselectedBox : require("../assets/images/unselectedBox.png"),
        selectedBox : require("../assets/images/selectedBox.png"),
        backBtn : require("../assets/images/backBtn.png"),
        emailGreen: require("../assets/images/emailGreen.png"),
        lockGreen: require("../assets/images/lockGreen.png"),
        hidePass: require("../assets/images/hidePass.png"),
        showPass: require("../assets/images/showPass.png"),
        appLogo : [
            require("../assets/images/logoLight.png"),
            require("../assets/images/logoDark.png"),
        ]
    },
    Drawer : {
        userDummy : require("../assets/images/userDummy.png"),
        menu : require("../assets/images/menu.png")
    },
    Home : {
        search : require("../assets/images/search.png"),
        radioSelected : require("../assets/images/radioSelected.png"),
        radioUnselected : require("../assets/images/radioUnselected.png"),
        serviceIcon : require("../assets/images/servicesIcon.png"),
        tag : require("../assets/images/tag.png"),
        globe : require("../assets/images/globe.png"),
        locationPin : require("../assets/images/locationPin.png"),
        mailPin : require("../assets/images/mailPin.png"),
        pencilNotes : require("../assets/images/pencilNotes.png"),
        clock : require("../assets/images/clock.png"),
        notes : require("../assets/images/notes.png"),
        whatsapp : require("../assets/images/whatsapp.png"),
        mobile : require("../assets/images/mobile.png"),
        telephone : require("../assets/images/telephone.png"),
        addContact : require("../assets/images/addContact.png"),
        message : require("../assets/images/message.png"),
        phoneWhite : require("../assets/images/phoneWhite.png"),
        dummyUser: require("../assets/images/dummyUser.png"),
    }
}
export const addList = [
    {
        name : "Ihope",
        image : require("../assets/images/iHopeLogo.png")
    },
    {
        name : "Skipshare",
        image : require("../assets/images/skipShareLogo.png")
    },
    {
        name : "Math Resolver",
        image : require("../assets/images/mathLogo.png")
    }
]
export const AppFonts = {
    Candarab: 'CANDARAB',
    PoppinBold: 'Poppins-Bold',
    PoppinsExtraLight: 'Poppins-ExtraLight',
    PoppinMedium: 'Poppins-Medium',
    CandaraBold: 'CANDARA-BOLD',
    PoppinsLight: 'Poppins-Light',
    PoppinsRegular: 'Poppins-Regular',
    PoppinsSemiBold: 'Poppins-SemiBold',
    beyondMountainRegular: 'BeyondTheMountains',
    beyondMountainRegularAndroid: 'beyond_the_mountains',
    sfCompactDisplayLight: Platform.OS == "android" ? "sf-compact-display-light" : "SFCompactDisplay-Light",
    sfCompactDisplayMedium: Platform.OS == "android" ? "sf-compact-display-medium" : "SFCompactDisplay-Medium",
    sfCompactDisplaySemiBold: Platform.OS == "android" ? "SF-Compact-Display-Semibold" : "SFCompactDisplay-SemiBold",
    sfCompactDisplayBold: Platform.OS == "android" ? "SF-Compact-Display-Bold" : "SFCompactDisplay-Bold",
    sfCompactDisplayRegular: Platform.OS == "android" ? "SF-Compact-Display-Regular" : "SFCompactDisplay-Regular",
    sfProDisplayRegular: Platform.OS == "android" ? "SF-Pro-Display-Regular" : "SFProDisplay-Regular",
    sfProDisplayMedium: Platform.OS == "android" ? "SF-Pro-Display-Medium" : "SFProDisplay-Medium",
    sfProDisplaySemiBold: Platform.OS == "android" ? "SF-Pro-Display-Semibold" : "SFProDisplay-SemiBold",
    sfProDisplayBold: Platform.OS == "android" ? "SF-Pro-Display-Bold" : "SFProDisplay-Bold",
    BaskervilleReg: "Baskerville-Regular",
    BaskervilleSemiBold: "Baskerville-SemiBold"
};

export const ContainerGuestList = [
    "login","profile","setting","career","ads","offer","invite","feedback","aboutUs"
]